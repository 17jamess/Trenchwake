# World-map verification

Observed in the connected Roblox Studio Server data model during a fresh Play session on 9 November 2026. Checks required `ReplicatedStorage.Warfront.WorldMap`, read its terrain/navigation data and populated its route cache. They did not alter ownership, buildings or match commands.

## Detailed terrain data

- The downloaded `assets/world-large.bin` contains **500,000 bytes**, representing **1,000 × 500** terrain cells. It is OpenFront's `resources/maps/world/map4x.bin`; source, licence and checksum are recorded in `assets/world-large.json` and `ATTRIBUTION.md`.
- Rejoining and decoding `TerrainData1.luau` through `TerrainData4.luau` locally reproduced the downloaded binary exactly. Both produced SHA-256 **d5db77572958fef4400b291c27da92aa44a882e4f5ed58478bca4c3f1b578fbf**.
- Local byte classification found **158,068** passable land cells and **341,932** water cells. The required Studio module independently reported **158,068** land cells, **10,688** coastal land cells and **129** geographic seed anchors.
- `World.Scale` is **2**. Geographic anchors and crop bounds use doubled coordinates; IDs remain one-based indices into the full raster. Every crop exposes a 500,000-byte global-coordinate land membership mask.

| Variant | Dimensions | Land cells | Inclusive global bounds |
| --- | --- | --- | --- |
| World | 1,000 × 500 | 158,068 | (0, 0)–(999, 499) |
| Europe | 212 × 198 | 26,179 | (410, 24)–(621, 221) |
| Isles | 62 × 74 | 1,522 | (426, 60)–(487, 133) |

Each terrain ModuleScript is below 167 KB; `WorldMap.luau` is about 21 KB. This stays below the source-size limit encountered when assigning one large script through Studio.

## Navigation correctness

Navigation groups water into connected components within 8 × 8 blocks and joins them through cardinally adjacent boundary portals. Per-component trees provide exact water paths to the portals; smoothing only accepts water-visible shortcuts. The installed raster produced **6,149** graph nodes, **22,580 directed portal edges** and **3** connected water components.

The bounded test used random seed **20261109** and made **64 cold route requests**. Forty pairs sampled the complete coast list; 24 selected destinations within ±150 entries of the departure in the raster-ordered coast list. Nearby list entries are not guaranteed to be geographically nearby.

- All 22,580 portal edges had adjacent water endpoints, correct node assignments and matching connected-component labels. Every node representative was a tree root.
- **63** requests returned a route and **1** correctly returned no route because its endpoint water components were disjoint. No reachability mismatch was observed.
- Every returned route began and ended at the requested land cell. Every interior waypoint was water.
- An independent route-leg validator sampled every segment between interior waypoints at **four samples per cell of maximum-axis travel**. It found **no land crossings**. The first and last land-to-water legs were not included in this numerical segment check; route construction obtains those water cells from cardinal endpoint neighbors.
- Reachability expectations came from the constructed graph's component labels. This checks consistency between graph connectivity and route search, rather than independently flood-filling all water for every pair.

## Observed route performance

All 64 requests were confirmed cache misses using the module's cold-request counter. Each case yielded before the next case so the benchmark did not run as one long main-thread block. Timings below include the complete synchronous `routeWater` call, including path construction, smoothing and returned-path copying.

| Measure | Time |
| --- | ---: |
| Mean | 1.623012 ms |
| Median | 1.286900 ms |
| 95th percentile | 3.897900 ms |
| Maximum | 6.239100 ms |

The slowest request was cell **467907 → 53427**. It expanded **2,207** graph nodes and returned **23** points. The graph's eager server startup build took **2,482.424900 ms wall time**, including scheduled yields. That is not total game startup time or an isolated CPU-only measurement. Clients decode terrain but do not build the navigation graph.

The earlier 500 × 250 map fixture recorded 25 cold full-grid searches averaging 30.54 ms, with a 100.14 ms maximum. That was a different sample set and session, so it is historical context rather than a controlled same-route comparison. No cached-lookup latency was remeasured on the larger raster.

## Limits

These measurements describe this Studio host and a bounded route sample, not a guaranteed time budget, every possible coastal pair, a full multiplayer load or physical mobile devices. Uncached routes remain synchronous; callers should limit how many they begin in one simulation step. The graph/tree search favors bounded work and preserves water connectivity; its smoothed route is not guaranteed to be the globally shortest route. Cache-isolation mutation checks and invalid/inland endpoint checks from the previous fixture were not repeated in this pass.

The old 500 × 250 binary remains in `assets/world.bin` as a reference fixture. No WorldMap runtime error was observed during these larger-map checks.
