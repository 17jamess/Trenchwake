param(
    [string]$OutputPath = (Join-Path $PSScriptRoot 'Trenchwake.rbxlx')
)

# Builds a self-contained Roblox XML place with no external tools or downloads.
# All ProtectedString source is checked byte-for-character after XML round trip.
$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
# The source archive excludes dist/place outputs, so packaging before embedding
# has no circular dependency. ServerStorage keeps this material off clients.
& (Join-Path $packageRoot 'package-source.ps1') | Out-Null
$sourceArchivePath = Join-Path $packageRoot 'dist/Trenchwake-Source.zip'
$sourceArchiveHash = (Get-FileHash -LiteralPath $sourceArchivePath -Algorithm SHA256).Hash
$sourceArchiveBase64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($sourceArchivePath))
$placeXml = [System.Xml.XmlDocument]::new()
$placeXml.PreserveWhitespace = $true
$declaration = $placeXml.CreateXmlDeclaration('1.0', 'utf-8', $null)
$null = $placeXml.AppendChild($declaration)
$dataModel = $placeXml.CreateElement('roblox')
$dataModel.SetAttribute('version', '4')
$null = $placeXml.AppendChild($dataModel)

foreach ($value in @('null', 'nil')) {
    $external = $placeXml.CreateElement('External')
    $external.InnerText = $value
    $null = $dataModel.AppendChild($external)
}
$meta = $placeXml.CreateElement('Meta')
$meta.SetAttribute('name', 'ExplicitAutoJoints')
$meta.InnerText = 'true'
$null = $dataModel.AppendChild($meta)
$script:placeReferent = 0

function Add-PlaceProperty($properties, [string]$kind, [string]$propertyName, [string]$value) {
    $property = $placeXml.CreateElement($kind)
    $property.SetAttribute('name', $propertyName)
    $property.InnerText = $value
    $null = $properties.AppendChild($property)
}

function Add-PlaceItem($parentNode, [string]$className, [string]$instanceName) {
    $node = $placeXml.CreateElement('Item')
    $node.SetAttribute('class', $className)
    $node.SetAttribute('referent', 'RBX' + $script:placeReferent)
    $script:placeReferent++
    $null = $parentNode.AppendChild($node)
    $properties = $placeXml.CreateElement('Properties')
    $null = $node.AppendChild($properties)
    Add-PlaceProperty $properties 'string' 'Name' $instanceName
    return @{ Node = $node; Properties = $properties }
}

function Add-PlaceColor($properties, [string]$propertyName, [double]$channelValue) {
    $color = $placeXml.CreateElement('Color3')
    $color.SetAttribute('name', $propertyName)
    foreach ($channel in @('R', 'G', 'B')) {
        $component = $placeXml.CreateElement($channel)
        $component.InnerText = $channelValue.ToString([System.Globalization.CultureInfo]::InvariantCulture)
        $null = $color.AppendChild($component)
    }
    $null = $properties.AppendChild($color)
}

$workspaceNode = Add-PlaceItem $dataModel 'Workspace' 'Workspace'
Add-PlaceProperty $workspaceNode.Properties 'bool' 'StreamingEnabled' 'false'
$cameraNode = Add-PlaceItem $workspaceNode.Node 'Camera' 'Camera'
Add-PlaceProperty $workspaceNode.Properties 'Ref' 'CurrentCamera' $cameraNode.Node.GetAttribute('referent')
Add-PlaceProperty $cameraNode.Properties 'float' 'FieldOfView' '40'
$frame = $placeXml.CreateElement('CoordinateFrame')
$frame.SetAttribute('name', 'CFrame')
$coordinates = [ordered]@{ X=0; Y=10000; Z=0; R00=1; R01=0; R02=0; R10=0; R11=0; R12=1; R20=0; R21=-1; R22=0 }
foreach ($entry in $coordinates.GetEnumerator()) {
    $coordinate = $placeXml.CreateElement($entry.Key)
    $coordinate.InnerText = [string]$entry.Value
    $null = $frame.AppendChild($coordinate)
}
$null = $cameraNode.Properties.AppendChild($frame)

$lightingNode = Add-PlaceItem $dataModel 'Lighting' 'Lighting'
foreach ($entry in ([ordered]@{ Brightness=1; ClockTime=12; EnvironmentDiffuseScale=0; EnvironmentSpecularScale=0 }).GetEnumerator()) {
    Add-PlaceProperty $lightingNode.Properties 'float' $entry.Key ([string]$entry.Value)
}
Add-PlaceProperty $lightingNode.Properties 'string' 'TimeOfDay' '12:00:00'
Add-PlaceProperty $lightingNode.Properties 'bool' 'GlobalShadows' 'false'
Add-PlaceColor $lightingNode.Properties 'Ambient' (120.0 / 255.0)
Add-PlaceColor $lightingNode.Properties 'OutdoorAmbient' (120.0 / 255.0)

$replicatedNode = Add-PlaceItem $dataModel 'ReplicatedStorage' 'ReplicatedStorage'
$sharedNode = Add-PlaceItem $replicatedNode.Node 'Folder' 'Warfront'
$serverNode = Add-PlaceItem $dataModel 'ServerScriptService' 'ServerScriptService'
$serverFolderNode = Add-PlaceItem $serverNode.Node 'Folder' 'Warfront'
$starterNode = Add-PlaceItem $dataModel 'StarterPlayer' 'StarterPlayer'
$starterScriptsNode = Add-PlaceItem $starterNode.Node 'StarterPlayerScripts' 'StarterPlayerScripts'
$starterGuiNode = Add-PlaceItem $dataModel 'StarterGui' 'StarterGui'
# Verified in Studio: Enum.ScreenOrientation.LandscapeSensor.Value == 2.
Add-PlaceProperty $starterGuiNode.Properties 'token' 'ScreenOrientation' '2'
$playersNode = Add-PlaceItem $dataModel 'Players' 'Players'
Add-PlaceProperty $playersNode.Properties 'bool' 'CharacterAutoLoads' 'false'

$sources = @(
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='Config'; Path='src/shared/Config.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='CombatRules'; Path='src/shared/CombatRules.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='CampaignRules'; Path='src/shared/CampaignRules.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='RailNetwork'; Path='src/shared/RailNetwork.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='WorldMap'; Path='src/shared/WorldMap.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='StateInbox'; Path='src/client/StateInbox.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='MapRenderer'; Path='src/client/MapRenderer.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='Interface'; Path='src/client/Interface.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='ButtonFeedback'; Path='src/client/ButtonFeedback.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='FieldArt'; Path='src/client/FieldArt.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='FieldSkin'; Path='src/client/FieldSkin.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='BattleHUD'; Path='src/client/BattleHUD.luau' },
    @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name='GameTheme'; Path='src/client/GameTheme.luau' },
    @{ Parent=$serverFolderNode.Node; Class='ModuleScript'; Name='MatchService'; Path='src/server/MatchService.luau' },
    @{ Parent=$serverFolderNode.Node; Class='ModuleScript'; Name='AttackFrontier'; Path='src/server/AttackFrontier.luau' },
    @{ Parent=$serverFolderNode.Node; Class='ModuleScript'; Name='StrategyAI'; Path='src/server/StrategyAI.luau' },
    @{ Parent=$serverFolderNode.Node; Class='Script'; Name='Bootstrap'; Path='src/server/Bootstrap.server.luau' },
    @{ Parent=$starterScriptsNode.Node; Class='LocalScript'; Name='WarfrontClient'; Path='src/client/Main.client.luau' }
)
foreach ($artModule in Get-ChildItem -LiteralPath (Join-Path $packageRoot 'src/shared') -Filter 'FieldArtData*.luau' | Sort-Object Name) {
    $sources += @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name=$artModule.BaseName; Path=('src/shared/' + $artModule.Name) }
}
foreach ($terrainModule in Get-ChildItem -LiteralPath (Join-Path $packageRoot 'src/shared') -Filter 'TerrainData*.luau' | Sort-Object Name) {
    $sources += @{ Parent=$sharedNode.Node; Class='ModuleScript'; Name=$terrainModule.BaseName; Path=('src/shared/' + $terrainModule.Name) }
}
$expectedSources = @{}
foreach ($source in $sources) {
    $scriptNode = Add-PlaceItem $source.Parent $source.Class $source.Name
    $sourceText = [System.IO.File]::ReadAllText((Join-Path $packageRoot $source.Path))
    Add-PlaceProperty $scriptNode.Properties 'ProtectedString' 'Source' $sourceText
    if ($source.Class -in @('Script', 'LocalScript')) {
        Add-PlaceProperty $scriptNode.Properties 'bool' 'Disabled' 'false'
    }
    $expectedSources[$source.Name] = $sourceText
}

$storageNode = Add-PlaceItem $dataModel 'ServerStorage' 'ServerStorage'
$distributionNode = Add-PlaceItem $storageNode.Node 'Folder' 'SourceDistribution'
$distributionValues = [ordered]@{
    'README' = "Complete corresponding source for this Trenchwake version. The live Luau is already editable in this place. Archive chunks below contain the complete preferred source, assets, licences and build materials as a ZIP. They are data only, never executed. Save this place as Roblox XML (.rbxlx); run the ExtractSourcePowerShell text below or the supplied extract-source-distribution.ps1. This folder stays in ServerStorage and is not replicated to players."
    'ArchiveSHA256' = $sourceArchiveHash
    'ArchiveEncoding' = 'base64 ZIP, concatenate Archive001 onwards in name order'
    'ExtractSourcePowerShell' = [IO.File]::ReadAllText((Join-Path $packageRoot 'extract-source-distribution.ps1'))
    'LICENSE' = [IO.File]::ReadAllText((Join-Path $packageRoot 'LICENSE'))
    'LICENSE-ASSETS' = [IO.File]::ReadAllText((Join-Path $packageRoot 'LICENSE-ASSETS'))
    'ATTRIBUTION' = [IO.File]::ReadAllText((Join-Path $packageRoot 'ATTRIBUTION.md'))
}
$chunkSize = 100000
for ($offset = 0; $offset -lt $sourceArchiveBase64.Length; $offset += $chunkSize) {
    $chunkName = 'Archive{0:D3}' -f ([int]($offset / $chunkSize) + 1)
    $distributionValues[$chunkName] = $sourceArchiveBase64.Substring($offset, [Math]::Min($chunkSize, $sourceArchiveBase64.Length - $offset))
}
foreach ($entry in $distributionValues.GetEnumerator()) {
    $valueNode = Add-PlaceItem $distributionNode.Node 'StringValue' $entry.Key
    Add-PlaceProperty $valueNode.Properties 'string' 'Value' $entry.Value
}

$resolvedOutput = [System.IO.Path]::GetFullPath($OutputPath)
$writerSettings = [System.Xml.XmlWriterSettings]::new()
$writerSettings.Encoding = [System.Text.UTF8Encoding]::new($false)
$writerSettings.Indent = $true
$writerSettings.NewLineHandling = [System.Xml.NewLineHandling]::Entitize
$writer = [System.Xml.XmlWriter]::Create($resolvedOutput, $writerSettings)
try { $placeXml.Save($writer) } finally { $writer.Dispose() }

$roundTrip = [System.Xml.XmlDocument]::new()
$roundTrip.PreserveWhitespace = $true
$roundTrip.Load($resolvedOutput)
$scriptNodes = $roundTrip.SelectNodes('//Item[Properties/ProtectedString[@name="Source"]]')
if ($scriptNodes.Count -ne $sources.Count) { throw 'The packaged script count is incorrect.' }
foreach ($node in $scriptNodes) {
    $scriptName = $node.SelectSingleNode('Properties/string[@name="Name"]').InnerText
    $packagedSource = $node.SelectSingleNode('Properties/ProtectedString[@name="Source"]').InnerText
    if (-not [string]::Equals($packagedSource, $expectedSources[$scriptName], [System.StringComparison]::Ordinal)) {
        throw "The XML round trip changed source text: $scriptName"
    }
}
$distributionRoundTrip = $roundTrip.SelectSingleNode('//Item[@class="Folder"][Properties/string[@name="Name"]="SourceDistribution"]')
foreach ($entry in $distributionValues.GetEnumerator()) {
    $saved = $distributionRoundTrip.SelectSingleNode('Item[Properties/string[@name="Name"]="' + $entry.Key + '"]/Properties/string[@name="Value"]')
    if (-not $saved -or $saved.InnerText -cne $entry.Value) { throw "Source distribution changed during XML round trip: $($entry.Key)" }
}

[ordered]@{
    Place = $resolvedOutput
    Bytes = (Get-Item -LiteralPath $resolvedOutput).Length
    Scripts = $scriptNodes.Count
    SourceRoundTrip = 'exact'
    SourceArchiveSHA256 = $sourceArchiveHash
    SHA256 = (Get-FileHash -LiteralPath $resolvedOutput -Algorithm SHA256).Hash
} | ConvertTo-Json
