# Minimal interface revision — 11 November 2026

This revision replaces the broad persistent battle toolbar with floating controls and panels that appear only when requested. The home screen uses a bold arcade-style game graphic, three original vector illustrations, one Play action and three mode choices. The earlier AI command-tent wallpaper is no longer the home-screen direction. Figma access was attempted but the connected account's tool allowance blocked further work there; the implemented graphics and layout remain editable in the project.

## Battle layout

The default Playing HUD contains a 440 × 48 pixel dock for troop/capacity and gold values, Build, deployment percentage and More. A small land/goal pill includes the clock or opening-protection state. Zoom and Hide controls float separately. Leaderboard, active fronts, construction tools and deployment controls do not remain expanded over the map.

Build opens the complete ten-action palette. Deployment opens the original continuous slider and five presets, plus supply, troop growth and gold income. More exposes the existing Help, Settings, Rankings, Recenter and Leave actions, plus active fronts and individual retreat controls. Choosing a tool closes its palette for placement. Map clicks and Escape dismiss open panels. Tab/Hide provides a clean map; Show restores the default controls. An active placement can retain its small cancel/instruction pill.

All added buttons use the existing shared click sound and press/release feedback. Gameplay authority, prices, troop commitments and server command validation are unchanged.

## Verified in Studio

- A native desktop Solo flow selected a capital and entered Playing.
- At a 1043.2 × 536 viewport, the default dock measured approximately 440 × 48 pixels. Persistent rectangular HUD coverage was **6.218%**, with construction, deployment and More panels closed.
- Build opened its palette. Opening deployment closed the build palette. The 75% preset and a continuous-slider selection of 60% both updated the Send label.
- More → Rankings opened the native leaderboard and closed More. With no active placement, Hide left Show available; Show restored controls.
- More → Leave returned to the home screen and disabled the gameplay map ScreenGui.
- Native desktop clicks in a funded callback fixture routed all ten palette controls correctly: six build actions (City, Port, Factory, Defense, Silo and SAM), four weapon actions (Warship, Atom, Hydrogen and MIRV), then Cancel once—exactly eleven intended calls. This verifies native interface routing, not purchasing and firing every weapon in a live match.
- A separate native three-front fixture recalled attack IDs 501, 502 and 503 individually and exactly. The placement banner is hidden while a panel is open, preventing its Cancel control from covering palette actions; all ten routes passed again after that correction.
- The 750 × 381 phone-simulator fixture measured **12.167%** persistent HUD coverage. Its default layout was visually inspected.

Coverage sums the bounds of the persistent dock, progress pill, zoom capsule and Hide button; it excludes temporary panels, notices and modal dialogs. It is an interface-occupancy measurement, not a frame-rate or performance claim.

Physical touch remains unverified. The Studio automation mouse did not align reliably in the phone simulator, so desktop native-input results are not presented as phone-touch results. The funded palette and front fixtures establish callback routing; they do not replace live server/economy or production-device tests.

## Useful control paths

These paths are beneath `LocalPlayer.PlayerGui.WarfrontUI.Canvas`:

| Control | Path |
| --- | --- |
| Build palette toggle | `ActiveHUD.BattleDock.Build` |
| Deployment toggle | `ActiveHUD.BattleDock.Deployment` |
| Utilities toggle | `ActiveHUD.BattleDock.More` |
| Continuous deployment slider | `ActiveHUD.DeploymentPanel.AttackSlider` |
| Construction and weapon controls | `ActiveHUD.CommandBar.City` through `ActiveHUD.CommandBar.MIRV` |
| Active fronts | `ActiveHUD.BattleMenu.Fronts` |
| Hide / Show | `ActiveHUD.MapView` |
| Capital-stage utilities | `ActiveHUD.SpawnMenu` |
| Existing utility actions | `Header.Help`, `Header.Settings`, `Header.Ranking`, `Header.World`, `Header.Exit` |

Reopen Build before each tool selection when testing all ten actions: a selection intentionally closes the palette. `BattleHUD.luau` owns the compact presentation; `Interface.luau` retains gameplay callbacks and applies BattleHUD after the home-screen skin.
