# Source code and licenses

The combined game code includes Luau adaptations of OpenFront and is distributed under **GNU Affero General Public License version 3**, including the additional attribution/origin terms in [LICENSE](LICENSE). The map and adapted geography are **CC BY-SA 4.0**; see [ATTRIBUTION.md](ATTRIBUTION.md) and [LICENSE-ASSETS](LICENSE-ASSETS).

**© OpenFront and Contributors.** This is a modified, unofficial Roblox adaptation without OpenFront endorsement. No warranty is provided.

## Free source through Roblox

The configured source offer uses [the game's Roblox page](https://www.roblox.com/games/123209925514168), also the value of `Config.SourceURL`. On that page, choose **⋯ → Edit in Studio**, then save a copy. The published start place must have **Allow users to download a copy of this Place** enabled. See Roblox's [official copying instructions](https://create.roblox.com/docs/projects/configure-games#allow-copying).

All running Luau is editable in that copy. **ServerStorage.SourceDistribution** additionally contains the complete corresponding-source ZIP, its SHA-256 and an extractor. The archive includes preferred source, editable licensed assets, notices, QA, build scripts and setup documentation. This labelled data is never executed and does not replicate to clients.

Save the copy as **Roblox XML (.rbxlx)**, then run:

```powershell
./extract-source-distribution.ps1 -PlacePath ./Trenchwake.rbxlx -OutputPath ./Trenchwake-Source.zip
```

The extractor verifies the embedded SHA-256 before writing the ZIP. It is also supplied as the `ExtractSourcePowerShell` StringValue. Extract the ZIP and run `./rebuild-place.ps1` to rebuild. See [SOURCE_DISTRIBUTION.md](SOURCE_DISTRIBUTION.md).

An additional public mirror is configured at **https://github.com/17jamess/Trenchwake**. The repository has been created; uploading and verifying this release's contents remains part of release preparation. The in-game offer directs players to Roblox's own copying route rather than an external address.

## Preferred source and rebuild materials

Editable Luau files are under `src/`; preferred map/artwork inputs are under `assets/`. Portable data modules make the assets available in Roblox. Provenance and modifications are recorded in COMBAT_PORT.md, AI_PORT.md, CAMPAIGN_PORT.md and ATTRIBUTION.md.

`rebuild-place.ps1` first invokes `package-source.ps1`, then embeds that exact `dist/Trenchwake-Source.zip` into the generated place. The builder verifies all 56 production scripts/modules after an XML round trip; StringValues containing source-distribution data add no executable scripts.

The archive includes `src/`, `assets/`, `qa/` when present, and top-level Markdown/text documentation, licence files and PowerShell scripts, with a SHA-256 manifest. Generated outputs, `dist/` and reference downloads are excluded, avoiding a circular dependency. A place containing only the running scripts would omit preferred artwork and build materials; preserve the full source archive and extractor.

## Release verification and ongoing availability

The source-download route and offer are implemented in the local build. This document is **not confirmation of public Roblox access, account eligibility, completed mirror upload or non-owner copying**. A private cloud version may be prepared while these steps are completed.

Before public access, verify that the released place permits copying, a non-owner can obtain its editable copy, and its extracted ZIP matches the embedded hash and exact deployed source. Keep the prominent Credits/Source offer and public mirror synchronized with every later release.

AGPL section 13 requires a prominent opportunity for remote users to receive the version's Corresponding Source through free, standard or customary network copying. Distribution may also carry section 6 obligations. This supported Roblox copying route is a practical source-delivery implementation, not a blanket legal determination of compatibility with every platform term.

Preserve **“© OpenFront and Contributors”**, modified/unofficial status, licence information and the no-warranty notice. The Roblox description now explains the on-platform copy route without an external-link placeholder. Credit alone does not replace source availability or other licence obligations.

## Asset boundaries

The upstream LICENSE-ASSETS is preserved verbatim; its `/resources` and `/proprietary` paths describe the upstream repository. This game includes open World terrain and adapted crops, excluding proprietary OpenFront and premium assets.

CC BY-SA requires attribution, a licence reference, identification of changes and share-alike for adapted assets. The code licence follows the actual source adaptations and the chosen licence for the combined program. Check each additional asset's permission before inclusion.
