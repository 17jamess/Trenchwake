# Campaign supply reach — 9 November 2026

The campaign's distinctive rule is **forward supply**. A held capital, completed city or completed port supports nearby advances. Long pushes become gradually slower and more expensive; building or capturing a forward base restores support. The same rules apply to humans, major AI nations, minor AI nations and naval landings.

## Evidence and provenance

Inspected OpenFrontIO commit `59742761c2b75d6f3ac583c21d6007b8e542e786`:

- `packages/engine/src/configuration/EngineConfig.ts`, `attackLogic`: separates attacker casualties, defender density losses and per-cell tick cost; terrain and defense posts affect costs.
- `packages/engine/src/execution/AttackExecution.ts`, `tick`: applies those costs to a validated contiguous frontier with a tick budget.
- `packages/engine/src/execution/PlayerExecution.ts`: maintains troop growth and economy separately from attack execution.

These existing separations make it possible to add supply modifiers without changing ownership validation, regeneration, attack commitments or the frontier algorithm. **Supply reach is an original extension for this Roblox game, not a claim that OpenFront contains this supply mechanic.** `CampaignRules.luau` contains no translated upstream function. It is distributed under the combined project's AGPL-3.0 license; existing upstream attribution and asset terms remain in effect.

## Exact API

`CampaignRules.evaluate({x, y, mapWidth, anchors})` returns:

- `efficiency`: 0.45–1; support quality for an attack on this cell.
- `lossMultiplier`: 1–1.44; multiply **attacker** troop loss from `CombatRules.resolve`.
- `timeMultiplier`: 1–1.77; multiply `tickFraction` from `CombatRules.resolve`.
- `status`: `SECURE`, `EXTENDED` or `OVERSTRETCHED`.
- `anchorGap`: nearest effective distance measured in supply radii, capped at 8.
- `nearestDistance`: distance in map cells to the selected supporting anchor. With no valid anchor it is the finite sentinel `mapWidth * 8`.
- `range`: selected anchor's supply radius, or 0 when none is valid.

`CampaignRules.anchorGap(x, y, mapWidth, anchors)` returns the same finite gap score without allocating a result table. It is intended for a bounded AI placement search: prefer useful frontier city/port sites farther from existing support, while still enforcing normal ownership, terrain, spacing and cost validation.

`CampaignRules.anchorRange(anchor, mapWidth)` returns the anchor's effective radius. Unknown anchor kinds return 0 and are ignored.

An anchor is `{x=number, y=number, kind="Capital"|"City"|"Port", level=number?}`. The caller supplies **only currently owned, eligible anchors**. A capital must still be held. City and port construction must be completed (`level > 0`). Level defaults to 1. The module never mutates this list or any game state.

For the server's repeated capture calculations, `CampaignRules.compile(anchors, mapWidth)` caches validated anchor coordinates and squared radii. `CampaignRules.modifiers(x, y, compiled)` returns the same `efficiency, lossMultiplier, timeMultiplier` as three numbers, avoiding per-cell input/result tables and repeated range validation. Any base covering the location permits an immediate full-support return. Recompile after an eligible base changes, not every frame. The detailed `evaluate` API remains unchanged.

## Constants and tuning

Supply radii are map-relative: capital `0.045 * mapWidth`, city `0.036 * mapWidth`, port `0.030 * mapWidth`. For a 2,000-cell-wide world, that is 90, 72 and 60 cells. Use the active map/crop width so regional matches receive sensible reach too.

City and port radii grow 12% per level above 1, capped at four bonus levels. Capital reach has no level bonus. Support is full inside one radius and falls smoothly to its 45% floor at three radii. A nearer coordinate does not always win: support is selected by distance divided by effective anchor range.

There is no idle attrition, economy penalty or troop-regeneration penalty. Even with no capital/city/port, an empire can still advance with bounded surcharges. This avoids a supply-loss softlock and keeps the mechanic legible: **hold bases, build forward, then push**.

## Integration contract

1. Cache a compact anchor list and compiled modifiers per empire. Rebuild only when an eligible structure completes/changes owner or a capital changes ownership. Ordinary cell capture and unrelated factories/defenses/silos do not require rebuilding every list.
2. At a valid cell capture or naval landing, obtain the normal combat result and multiply only attacker loss and tick cost. Defender density losses remain those from `CombatRules`; normal server adjacency/ownership checks are unchanged.
3. If a capital falls with no building on that tile, invalidate supply anyway. A captured completed city/port becomes the new owner's forward base after the usual ownership update.
4. For AI cities/ports, search the existing bounded frontier/owned sample using `anchorGap` before falling back to capital placement. Repeatedly upgrading the capital first does not establish forward support.
5. Do not scan all map cells each frame. The pure evaluation loops over the cached anchors; the AI placement search remains bounded.

## Meaningful validation cases

- At a held capital: full efficiency, no surcharge.
- At two increasingly distant points outside its radius: monotonic loss/time costs, bounded by the stated maxima.
- Adding a completed forward city at a distant point restores full support there without changing the original anchor list.
- Removing the last eligible anchor applies the finite floor and still permits conquest.
- A higher-level city increases its reach; an unknown anchor kind adds no support.
- Doubling map width and every coordinate leaves efficiency unchanged.
- Repeated evaluation does not mutate input anchors or game state.
- Existing frontier/landing tests must continue to enforce troop conservation and server ownership rules after applying the modifiers.

Balance values are initial tuning. Simulation and real-player feedback should determine whether full campaigns take the intended time; this document does not claim production balance has been verified.
