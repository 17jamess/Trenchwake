# High-resolution World terrain

`world-full.bin` is the unmodified 2000 × 1000 World map from OpenFront's
`resources/maps/world/map.bin`, downloaded in the local reference checkout at
commit `59742761c2b75d6f3ac583c21d6007b8e542e786`.

Original source:
https://github.com/openfrontio/OpenFrontIO/blob/59742761c2b75d6f3ac583c21d6007b8e542e786/resources/maps/world/map.bin

**Attribution: OpenFront / OpenFront Inc. — © OpenFront and Contributors.**
The terrain is licensed under Creative Commons Attribution-ShareAlike 4.0:
https://creativecommons.org/licenses/by-sa/4.0/

The raster contains 2,000,000 cells, of which 651,569 are playable land. Its
SHA-256 is `a0d7b174f90dfd654c6d660e498d25944caadae07fbb980600452115422398f9`.
It replaces the previous simulation raster's 158,068 land cells with 4.12 times
as many land cells and more detailed coastline/terrain. Europe and Isles remain
geographic crops with their bounds doubled to preserve the same regions.

Run `./assets/rebuild-world-data.ps1` from the project directory to regenerate
`TerrainData1.luau` through `TerrainData16.luau` and `TerrainDataManifest.luau`.
The builder verifies the generated base64 chunks decode exactly to the preferred
binary source. The original lower-resolution `world-large.bin` remains unchanged
for the separately created menu-art source and historical fixtures.

The Luau decoder, masks, label anchors and navigation helpers are project code
under the combined game's AGPL license. The data's adaptation/embedding and map
crops retain the asset license. This attribution does not imply endorsement.
