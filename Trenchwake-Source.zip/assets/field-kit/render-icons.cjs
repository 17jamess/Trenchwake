// Optional SVG-to-PNG rebuild for the exact six field-kit construction icons.
// PNGs are already included. Install sharp or set FIELD_ART_SHARP to its module path.
const fs = require('node:fs');
const path = require('node:path');
const sharp = require(process.env.FIELD_ART_SHARP || 'sharp');
(async () => {
  for (const key of ['CITY', 'PORT', 'FACTORY', 'DEFENSE', 'SILO', 'SAM']) {
    const input = path.join(__dirname, `icon-${key}.svg`);
    const output = path.join(__dirname, `icon-${key}.png`);
    await sharp(fs.readFileSync(input)).resize(64, 64).png().toFile(output);
    process.stdout.write(`${key}: 64 x 64\n`);
  }
})().catch(error => { process.stderr.write(`${error.stack}\n`); process.exitCode = 1; });
