param(
    [string]$EdgePath = 'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
    [ValidateSet('nav-guide', 'nav-colours', 'nav-credits', 'hud-troops', 'hud-gold', 'hud-build', 'hud-send')]
    [string[]]$Icons = @('nav-guide', 'nav-colours', 'nav-credits', 'hud-troops', 'hud-gold', 'hud-build', 'hud-send')
)

# Optional SVG-to-PNG asset rebuild using an existing Microsoft Edge install.
# Preferred PNGs are supplied; ordinary game/place builds do not need Edge.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

if (-not (Test-Path -LiteralPath $EdgePath -PathType Leaf)) {
    throw 'Microsoft Edge was not found. Pass -EdgePath with its existing executable path; no dependency is installed by this script.'
}
$assetRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$projectRoot = [IO.Path]::GetFullPath((Join-Path $assetRoot '../..'))
$projectPrefix = $projectRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$renderRoot = [IO.Path]::GetFullPath((Join-Path $projectRoot 'tmp/nav-renderer'))
if (-not $renderRoot.StartsWith($projectPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'The temporary renderer directory must stay inside the project.'
}
$null = New-Item -ItemType Directory -Path $renderRoot -Force

foreach ($stem in $Icons) {
    $svgPath = Join-Path $assetRoot ($stem + '.svg')
    $pngPath = Join-Path $assetRoot ($stem + '.png')
    if (-not (Test-Path -LiteralPath $svgPath -PathType Leaf)) {
        throw "Missing editable SVG: $svgPath"
    }
    $svgUri = [Uri]::new($svgPath).AbsoluteUri
    # Quotes are intentional: Start-Process joins ArgumentList into the native
    # Windows command line, and the project directory may contain spaces.
    $edgeArguments = '--headless --disable-gpu --no-first-run --no-default-browser-check --hide-scrollbars --default-background-color=00000000 --window-size=96,96'
    $edgeArguments += ' --user-data-dir="' + $renderRoot + '"'
    $edgeArguments += ' --screenshot="' + $pngPath + '" "' + $svgUri + '"'
    $process = Start-Process -FilePath $EdgePath -ArgumentList $edgeArguments -WindowStyle Hidden -Wait -PassThru `
        -RedirectStandardError (Join-Path $renderRoot ($stem + '-error.txt')) `
        -RedirectStandardOutput (Join-Path $renderRoot ($stem + '-output.txt'))
    if ($process.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $pngPath -PathType Leaf)) {
        throw "SVG conversion failed for $stem. See its renderer log under $renderRoot."
    }

    $bitmap = [Drawing.Bitmap]::new($pngPath)
    try {
        if ($bitmap.Width -ne 96 -or $bitmap.Height -ne 96) {
            throw "Unexpected raster dimensions for $stem."
        }
        if ($bitmap.GetPixel(0, 0).A -ne 0) {
            throw "Expected a transparent background for $stem."
        }
        [ordered]@{
            File = $pngPath
            Width = $bitmap.Width
            Height = $bitmap.Height
            CornerAlpha = $bitmap.GetPixel(0, 0).A
        } | ConvertTo-Json -Compress
    }
    finally { $bitmap.Dispose() }
}
