// Verify that every portable image stream decodes to the encoder's RGBA hash.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const shared = path.resolve(__dirname, '../../src/shared');
const manifest = fs.readFileSync(path.join(shared, 'FieldArtData.luau'), 'utf8');
const entries = [...manifest.matchAll(/^(\w+)=\{width=(\d+),height=(\d+),bytes=(\d+),chunks=\{([^}]+)\},sha256="([a-f0-9]+)"\},/gm)];
if (entries.length !== 17) throw new Error(`Expected 17 images, found ${entries.length}`);
for (const [, key, width, height, expectedBytes, names, expectedHash] of entries) {
  const chunkNames = [...names.matchAll(/"([^"]+)"/g)].map(m => m[1]);
  const encoded = chunkNames.map(name => {
    const source = fs.readFileSync(path.join(shared, `${name}.luau`), 'utf8');
    const payload = source.match(/return \[\[([A-Za-z0-9+/=]+)\]\]/);
    if (!payload) throw new Error(`Invalid chunk ${name}`);
    if (Buffer.byteLength(source) >= 140000) throw new Error(`Oversized chunk ${name}`);
    return payload[1];
  }).join('');
  const input = Buffer.from(encoded, 'base64');
  const output = Buffer.alloc(Number(expectedBytes));
  let dictionary = [], nextCode = 258, previous = null, written = 0;
  for (let offset = 0; offset < input.length; offset += 2) {
    const code = input.readUInt16LE(offset);
    if (code === 256) { dictionary = []; nextCode = 258; previous = null; continue; }
    if (code === 257) break;
    let entry = code < 256 ? String.fromCharCode(code) : dictionary[code];
    if (entry === undefined && code === nextCode && previous !== null) entry = previous + previous[0];
    if (entry === undefined || written + entry.length > output.length) throw new Error(`Invalid stream for ${key}`);
    Buffer.from(entry, 'latin1').copy(output, written);
    written += entry.length;
    if (previous !== null && nextCode <= 65535) dictionary[nextCode++] = previous + entry[0];
    previous = entry;
  }
  const hash = crypto.createHash('sha256').update(output).digest('hex');
  if (written !== output.length || hash !== expectedHash) throw new Error(`Round-trip failure for ${key}`);
  if (key === 'Emblem' && output[3] !== 0) throw new Error('Emblem corner must remain transparent');
  process.stdout.write(JSON.stringify({key, width:Number(width), height:Number(height), chunks:chunkNames.length, rgbaBytes:written, sha256:hash, pass:true}) + '\n');
}
