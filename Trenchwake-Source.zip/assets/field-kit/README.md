# Portable Trenchwake artwork

Source images are embedded as EditableImages. No image asset IDs, runtime HTTP requests or uploads are required. Enable the experience's Allow Mesh / Image APIs setting.

## Current lobby graphics — 11 November 2026

- `trenchwake-wordmark-v1.png`: original transparent TRENCHWAKE title and territory-pennant mark, generated once with the built-in image tool. Exact prompt: `wordmark-prompt.txt`. Embedded as `LobbyLogo`, 768 × 256. All interface buttons and other text remain native Roblox UI.
- `nav-guide.svg`, `nav-colours.svg`, `nav-credits.svg`: three original editable illustrations: folded map/pin, red-blue flag, and book/ribbon. Their included transparent 96 × 96 PNGs were rasterized with existing Edge headless, without image generation or installing dependencies. Embedded as `NavGuide`, `NavColours`, `NavCredits`. `render-nav.ps1` is the optional local rasterization helper; ordinary place builds use the included PNGs.
- `hud-troops.svg`, `hud-gold.svg`, `hud-build.svg`, `hud-send.svg`: four additional original illustrations for army, gold, building and deployment. Included transparent PNGs are 96 × 96 and embed as HudTroops, HudGold, HudBuild and HudSend. These were authored and rasterized locally; this pass used no image generation.
- `ww2-world-map.png`: decorative World map derived from OpenFront geography. © OpenFront and Contributors; OpenFront / OpenFront Inc. CC BY-SA 4.0, https://creativecommons.org/licenses/by-sa/4.0/. Changes include framing, decorative Voronoi regions, palette, elevation shading and vignette. These regions are not historical national boundaries.
- `icon-*.svg`: six original construction icons from the earlier Figma composition, with included 64 × 64 PNGs. `render-icons.cjs` optionally recreates them with sharp; that dependency is not needed for ordinary game builds.

The older helmet illustration (`Emblem`) and command-tent illustration (`Headquarters`) are retained as licensed historical source assets. They are not displayed by the current home screen. The old prompt is `headquarters-prompt.txt`; the current revision used one new title generation and three authored vector illustrations.

Original project graphics are offered under CC BY-SA 4.0, as recorded in ATTRIBUTION.md. No third-party Roblox game artwork or branding was copied.

## Rebuild and verify

Run `./rebuild-field-art.ps1` in this folder to rebuild every embedded image, or `./rebuild-field-art.ps1 -Keys LobbyLogo,NavGuide,NavColours,NavCredits` to update those keys while preserving existing metadata. It uses Windows PowerShell/.NET System.Drawing only. All PNG inputs are shipped.

Large artwork uses 5-bit RGB and 4-bit alpha; small icons retain full RGBA. Streams use LZW16 plus base64 and split into modules below 140 KB. The manifest records decoded RGBA SHA-256 hashes. `node verify-field-art.cjs` checks all seventeen streams exactly. The cached runtime decoder is src/client/FieldArt.luau.

Figma was attempted again for this revision, but the connected account's MCP allowance prevented canvas edits. The current lobby layout is implemented in FieldSkin.luau and the minimal battle layout in BattleHUD.luau; historical Figma frames are not presented as this revision.
