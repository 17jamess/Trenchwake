// Offline validation of the preferred full map and its embedded Luau chunks.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const shared = path.join(__dirname, '../src/shared');
const terrain = fs.readFileSync(path.join(__dirname, 'world-full.bin'));
const manifest = fs.readFileSync(path.join(shared, 'TerrainDataManifest.luau'), 'utf8');
const chunks = [...manifest.matchAll(/"(TerrainData\d+)"/g)].map(m => m[1]);
const encoded = chunks.map(name => {
  const source = fs.readFileSync(path.join(shared, name + '.luau'), 'utf8');
  const match = source.match(/return \[\[([A-Za-z0-9+/=]+)\]\]/);
  assert(match, 'Malformed chunk ' + name);
  return match[1];
}).join('');
assert.equal(chunks.length, 16);
assert.equal(terrain.length, 2000000);
assert.deepEqual(Buffer.from(encoded, 'base64'), terrain);
const isLand = (x, y) => x >= 0 && x < 2000 && y >= 0 && y < 1000
  && terrain[y * 2000 + x] >= 128 && (terrain[y * 2000 + x] & 31) !== 31;
let land = 0, water = 0, impassable = 0;
const cropLand = { Europe: 0, Isles: 0 };
for (let y = 0; y < 1000; y++) for (let x = 0; x < 2000; x++) {
  if (isLand(x, y)) {
    land++;
    if (x >= 820 && x <= 1243 && y >= 48 && y <= 443) cropLand.Europe++;
    if (x >= 852 && x <= 975 && y >= 120 && y <= 267) cropLand.Isles++;
  } else if (terrain[y * 2000 + x] < 128) water++;
  else impassable++;
}
assert.equal(land, 651569);
const source = fs.readFileSync(path.join(shared, 'WorldMap.luau'), 'utf8');
const anchors = [...source.matchAll(/\{"([^"]+)",(\d+),(\d+),(true|false)\}/g)];
let maxRelocationRadius = 0;
for (const anchor of anchors) {
  const x = Number(anchor[2]) * 4, y = Number(anchor[3]) * 4;
  let found = isLand(x, y), radius = 0;
  while (!found && radius < 100) {
    radius++;
    for (let delta = -radius; delta <= radius; delta++) {
      if (isLand(x + delta, y - radius) || isLand(x + delta, y + radius)
        || isLand(x - radius, y + delta) || isLand(x + radius, y + delta)) {
        found = true;
        break;
      }
    }
  }
  assert(found, 'No nearby playable land for ' + anchor[1]);
  maxRelocationRadius = Math.max(maxRelocationRadius, radius);
}
console.log(JSON.stringify({ pass: true, width: 2000, height: 1000, chunks: chunks.length,
  land, water, impassable, cropLand, authoredAnchors: anchors.length, maxRelocationRadius,
  sha256: crypto.createHash('sha256').update(terrain).digest('hex') }));
