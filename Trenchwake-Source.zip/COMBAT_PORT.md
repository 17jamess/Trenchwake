# OpenFront combat adaptation

`src/shared/CombatRules.luau` adapts the combat calculations in OpenFront's `packages/engine/src/configuration/EngineConfig.ts` at commit `59742761c2b75d6f3ac583c21d6007b8e542e786`. Copyright © OpenFront and Contributors. The module is AGPL-3.0-only, including the upstream LICENSE's Section 7 attribution and origin terms. Modified 9 November 2026. A Luau translation remains an adaptation of the source; description credit alone is insufficient.

## Integration contract

`CombatRules.resolve(input)` accepts elevation, committed attack troops, attacker land count, optional minor flag, target troops (nil for neutral), target land count/minor flag, defense multiplier, front size and total playable land. It returns attacker loss, defender loss and tick fraction per cell. The routine has no Roblox instances, ownership mutation or randomness. `TickSeconds` is 0.1.

The server must check that each candidate is playable land, still belongs to the chosen target, and is adjacent to the attacker's land before applying the result. Spend `dt / TickSeconds` of a per-attack time budget, subtracting `tickFraction` for each conquest. Preserve a fractional remainder so small commitments are slower rather than granted one capture every update. Do not accumulate catch-up time while the global capture budget prevents work, and keep the existing per-session/per-attack work caps. Insufficient committed troops must not capture a cell. Debit only the actual available troops; never refund more than the surviving committed troops.

## Ported behavior

- Plains, highland and mountain use the upstream elevation thresholds (<10, <20, <31) and magnitudes 80/100/120 with time costs 16.5/20/25. Elevation 31 is impassable.
- Neutral land costs 16/20/24 troops for major/human nations and half that for minor nations. Speed scales with the committed stack and active frontier.
- Defenders lose their average troops per owned cell when a cell falls. Attacker casualties depend on the defender-to-attack troop ratio and defender troop density. Bigger commitments are more effective; weak attacks into concentrated armies are slower and more costly.
- The upstream minor-defender multiplier (0.7), troop-ratio bounds (0.6–2 for losses), speed curve and large-territory logistic bonuses are retained.

## Roblox tuning changes

The upstream 300,000-cell large-territory midpoint becomes 30% of the current playable map land count (minimum 1,000), so the mechanic can matter on this 158,068-land-cell world and its smaller crops. The active front is bounded to 64 for predictable work. A minimum tick fraction of 0.05 also bounds extreme speed. Existing level-based defensive multipliers are accepted: a fivefold casualty multiplier produces the upstream threefold time multiplier. Fallout, traitor penalties and disconnected-team transfer exceptions are omitted because this game has no matching state; friendly attacks remain the server's responsibility.

## Verification targets

Check neutral versus enemy losses, mountain versus plains, defense posts, troop-ratio improvements, zero defending troops, minor nations, finite positive results, and impassable rejection. In server fixtures verify exact initial troop commitment, no overspending, no refund duplication, no remote/island capture without a transport, repeated tiny time steps, bounded work under many attacks, and continuing expansion across newly captured cells. Compare a larger commitment with several small commitments: larger stacks should advance faster and pay fewer combat losses against an enemy, while neither can invent troops. Run a full AI-match soak after integration. Formula inspection alone is not a playtest or a performance result.
