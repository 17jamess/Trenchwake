# Command headquarters home screen — 9 November 2026

The new home screen uses an asymmetric command rail with stacked Trenchwake lettering and Solo deployment on the left. World Conquest and Team Front sit side by side over an original Roblox-style command-post illustration. This replaces the previous centred title/play-stack layout. Native text and buttons stay separate from the image.

The image was generated once with the built-in image tool. Editable input: assets/field-kit/headquarters-v1.png. Exact prompt: assets/field-kit/headquarters-prompt.txt. The portable Headquarters image is 768 × 512; all nine artwork streams passed decoded SHA-256 verification. No uploaded asset IDs or remote image downloads are required at runtime.

Native Studio clicks verified Profile, Field Manual, Credits/Source, Colours, sound and reduced-motion settings, both public queue types with correct lobby titles and leaving, and Solo setup. Solo press feedback reached 0.96 scale. Existing button callbacks and pooled click sound are preserved. All 62 base buttons/sliders retain feedback bindings.

In an actual solo session, a native map click selected an available capital, Start Here entered Playing, Map View hid/restored commands, and Exit returned home with the gameplay ScreenGui disabled. The new menu also appeared without allocating a gameplay atlas, and public queues did not allocate one.

Desktop and the 750 × 381 iPhone landscape simulator were inspected after the generated art loaded. The Solo button opened setup through native simulator input. Compact home button heights were increased slightly after inspection to allow for scale rounding. Physical touchscreen behavior and production-device performance remain unverified.

The historical Figma concept is retained as earlier art direction; the current home screen is implemented in src/client/FieldSkin.luau. It does not require further Figma generation or image calls.
