# Packages the preferred editable game source and licensed assets for release.
# This creates a local archive only; it does not publish or upload anything.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$projectRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd([IO.Path]::DirectorySeparatorChar)
$projectPrefix = $projectRoot + [IO.Path]::DirectorySeparatorChar
$filesByRelativePath = [Collections.Generic.Dictionary[string,string]]::new([StringComparer]::Ordinal)

function Add-SourceFile([IO.FileInfo]$file) {
    $absolute = [IO.Path]::GetFullPath($file.FullName)
    if (-not $absolute.StartsWith($projectPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Source path escapes the project: $absolute"
    }
    if (($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Do not package linked files: $absolute"
    }
    $relative = $absolute.Substring($projectPrefix.Length).Replace('\', '/')
    $filesByRelativePath.Add($relative, $absolute)
}

# Explicit roots prevent accidental inclusion of upstream proprietary/reference
# files or older builds. New game source belongs in these source roots.
foreach ($directoryName in @('src', 'assets', 'qa')) {
    $directoryPath = Join-Path $projectRoot $directoryName
    if (-not (Test-Path -LiteralPath $directoryPath -PathType Container)) {
        if ($directoryName -ne 'qa') { throw "Missing source directory: $directoryName" }
        continue
    }
    $directoryInfo = Get-Item -LiteralPath $directoryPath
    if (($directoryInfo.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Do not package linked directories: $directoryPath"
    }
    $children = @(Get-ChildItem -LiteralPath $directoryPath -Recurse -Force)
    foreach ($child in $children) {
        if (($child.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Do not package linked source entries: $($child.FullName)"
        }
        if (-not $child.PSIsContainer) { Add-SourceFile $child }
    }
}

foreach ($file in Get-ChildItem -LiteralPath $projectRoot -File -Force) {
    if ($file.Extension -in @('.md', '.txt', '.ps1') -or $file.Name -like 'LICENSE*') {
        Add-SourceFile $file
    }
}
foreach ($required in @('LICENSE', 'LICENSE-ASSETS', 'ATTRIBUTION.md', 'OPEN_SOURCE.md', 'README.md', 'rebuild-place.ps1', 'package-source.ps1')) {
    if (-not $filesByRelativePath.ContainsKey($required)) { throw "Missing release file: $required" }
}

$paths = [string[]]@($filesByRelativePath.Keys)
[Array]::Sort($paths, [StringComparer]::Ordinal)
$manifest = [Text.StringBuilder]::new()
$null = $manifest.Append("# SHA-256  relative path`n")
foreach ($relative in $paths) {
    $hash = (Get-FileHash -LiteralPath $filesByRelativePath[$relative] -Algorithm SHA256).Hash.ToLowerInvariant()
    $null = $manifest.Append($hash).Append('  ').Append($relative).Append("`n")
}

$distributionPath = Join-Path $projectRoot 'dist'
$null = New-Item -ItemType Directory -Path $distributionPath -Force
if (((Get-Item -LiteralPath $distributionPath).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
    throw 'The distribution directory must not be a link.'
}
$outputPath = Join-Path $distributionPath 'Trenchwake-Source.zip'
$temporaryPath = Join-Path $distributionPath ('Trenchwake-Source-' + [Guid]::NewGuid().ToString('N') + '.tmp')
$fixedTimestamp = [DateTimeOffset]::new(2000, 1, 1, 0, 0, 0, [TimeSpan]::Zero)
$utf8 = [Text.UTF8Encoding]::new($false)
$archive = $null
try {
    $stream = [IO.File]::Open($temporaryPath, [IO.FileMode]::CreateNew)
    $archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create, $false)
    foreach ($relative in $paths) {
        $entry = $archive.CreateEntry($relative, [IO.Compression.CompressionLevel]::Optimal)
        $entry.LastWriteTime = $fixedTimestamp
        $inputStream = [IO.File]::OpenRead($filesByRelativePath[$relative])
        $entryStream = $entry.Open()
        try { $inputStream.CopyTo($entryStream) }
        finally { $entryStream.Dispose(); $inputStream.Dispose() }
    }
    $manifestEntry = $archive.CreateEntry('SOURCES-MANIFEST.txt', [IO.Compression.CompressionLevel]::Optimal)
    $manifestEntry.LastWriteTime = $fixedTimestamp
    $writer = [IO.StreamWriter]::new($manifestEntry.Open(), $utf8)
    try { $writer.Write($manifest.ToString()) } finally { $writer.Dispose() }
    $archive.Dispose()
    $archive = $null
    Move-Item -LiteralPath $temporaryPath -Destination $outputPath -Force
}
finally {
    if ($null -ne $archive) { $archive.Dispose() }
    if (Test-Path -LiteralPath $temporaryPath -PathType Leaf) {
        Remove-Item -LiteralPath $temporaryPath
    }
}

$result = Get-FileHash -LiteralPath $outputPath -Algorithm SHA256
Write-Output ("Source archive: {0}" -f $outputPath)
Write-Output ("Files: {0} source/assets/docs plus manifest" -f $paths.Length)
Write-Output ("SHA-256: {0}" -f $result.Hash)
