# Map feedback, railways and AI — 11 November 2026

## Current behaviour

- Hovering during capital placement shows a brightened, translucent version of the actual starting disk: 49 cells on World, 13 on tiny maps, clipped to empty playable land. Clicking retains the selection. Distant preview rows stay at least one pixel tall and wide, with a faint outline.
- A small diamond briefly marks a map click and fades after 0.8 seconds. Friendly attack rings stay disabled; troop labels and recall controls remain available. Reduced motion suppresses the marker's size animation.
- City, Port, Factory, Defense, Silo and SAM markers use their existing illustrated graphics instead of letters, with an owner-colour edge. Each graphic decodes once per client; letters remain a fallback if allocation fails.
- A completed factory lays land-only railway connections to up to two nearby reachable completed cities/ports, including foreign facilities. The map-relative reach is 48–360 cells. Capturing endpoints preserves track geometry; demolishing one removes its affected links. Rail is persistent infrastructure, without a new economy or supply bonus.
- Rail searches are incremental: at most 160 heap operations per session step, with cached failures and no new full-world raster. Geometry is compressed to cardinal straight segments, with a 128-link / 1,024-segment graph budget. Clients receive it only after a revision or full sync and reuse the track image. Camera changes trigger line layout; stationary frames do not.
- The map has a full-viewport loading cover and progress indicator until its first raster upload completes, followed by a 0.35-second reveal. Reduced motion completes the reveal immediately. Initial framing fills the viewport instead of exposing a standalone rectangle.
- Opening battle zoom is 40% farther out. Simulation cells remain at 2,000 × 1,000 to avoid multiplying memory. A supplied front can capture at most six cells per attack tick, previously 36; total session capture work is capped at 192 cells, previously 480. Larger conquest goals are substantially harder; the existing 30-minute largest-territory result still applies.
- AI can afford its first neutral push from its starting army while retaining reserves. Bounded border checks now rotate through a cached complete frontier. Attack scheduling rotates its starting group so busy sessions cannot starve the same fronts, and finished attacks are compacted after the sweep.

## Native Studio results

The following checks passed in a fresh Studio playtest:

| Check group | Passed | Evidence |
| --- | ---: | --- |
| Gameplay regression | 52 | 120 simulated seconds with 168 AI; valid army/ownership bounds; land grew from 2,422 to 53,440 cells. |
| Forward supply regression | 27 | Existing supply, ownership and construction rules. |
| AI and scheduler | 21 | All 24 major and 144 minor nations made progress over 120 simulated seconds. No eligible nation stalled. A 224-front fixture exhausted the 192-cell budget, then every front had captured land within two ticks. A single supplied push captured six cells. |
| Railway geometry and integration | 23 | Both foreign endpoint links, unfinished facilities, water rejection, turn preservation, search budgets, cached failures, sparse snapshots and actual MatchService construction/conquest. Captured infrastructure retained the same links and revision. |
| Snapshot coalescing | 4 | Rare rail geometry updates survive later ordinary packets; empty revisions clear geometry; sessions stay separate. |
| Client map feedback | 16 | Exact spawn footprint, neutral clipping, selected fallback, subpixel regression, click state, rail reuse/session reset and upload/reduced-motion reveal. |
| Native building artwork | 6 | All six map building logos loaded successfully and hid their letter fallback. |

Total: **149 passing checks**. The six-logo check used an isolated client fixture with the actual renderer update and artwork decoder; it did not allocate another world raster.

A real desktop map click selected a valid capital and confirmed it. A later real click created an attack, incremented the click marker's visible counter once and retained its troop label with the gold ring disabled. The full-viewport World map was inspected after loading. Native verification caught zero-height distant preview rows; the final clamp and regression check address that defect.

The 168-AI activity fixture measured **1.405 ms mean**, **2.125 ms p95** and **3.728 ms maximum** per simulated 0.25-second service step on this Studio run. These are isolated simulation measurements, not production FPS or a 30-human network-load result. Physical touch and a full-duration campaign using this new balance remain unverified. No new image generation or paid external services were used for this revision.
