# Observed server checks

Tests ran in an isolated clone of `ServerScriptService.Warfront.MatchService` in the connected Studio Server data model on 8 November 2026. The clone used player-like Lua tables and had no publisher attached to live clients. Its sessions and funded fixtures were separate from the live game.

## First run: 46 passing checks

No failed assertion or game-simulation runtime error was observed before Studio was restarted. The restart disconnected the test instance and removed that temporary runtime fixture; the next naval-test command was rejected before execution because the old Studio ID was no longer connected.

The following scenarios passed:

- AI match creation entered Spawn with five opponents and one human participant.
- A water spawn was rejected; an unclaimed coastal California capital was accepted and began Playing.
- Troops and gold grew during one simulated second, and troop counts stayed within the calculated cap.
- A 35% deployment deducted exactly the floored commitment, then progressively captured frontier cells while the attack remained active.
- Retreat without an attack ID cleared all active attacks.
- Deployments at 1%, 10%, 25%, 50%, 75% and 100% each deducted exactly the expected commitment.
- Invalid fractions (zero, below 1%, over 100%, infinity and NaN) and invalid targets (negative, out of range, fractional, infinity, NaN and water) were rejected without spending troops.
- Building on foreign territory was rejected.
- Private pause froze match time; issuing an attack while paused was rejected; resume worked.
- City purchase deducted its exact configured price and began unfinished construction. A duplicate construction request was rejected.
- Completing the city raised troop capacity by at least 20,000. Nearby city placement violated the eight-tile spacing requirement and was rejected.
- Upgrading a city charged `floor(125000 * 1.65)` and completed at level 2, with two city levels counted.
- Placing a different building on an occupied tile was rejected.
- Factory, defense post, silo, SAM and coastal port purchases each deducted their configured prices; all completed and affected their respective empire building counts.
- Completed cities, a factory and a port increased gold income to approximately 6,557/sec in the fixture. Inland port placement was rejected.

Construction fixtures were deliberately funded with test gold so that expensive buildings could be checked without waiting for the natural economy. Troop commitments were reset between percentage cases. These observations establish the tested calculations and restrictions; they do not imply that 46 separate full user journeys or a production multiplayer match were played.

Navigation and terrain have separate evidence in `MAP_TESTING.md`. Live UI, actual-client multiplayer, and public Roblox hosting are separate tests.

## Follow-up run: 63 passing checks and one issue found

After Studio reopened and the alliance-offer handshake patch was installed, a fresh isolated clone of the 43,888-byte MatchService was required in the Server data model. The temporary ModuleScript was destroyed immediately after require; the returned service remained isolated in the test command's private state. Its empty sessions were removed when testing finished.

### Naval movement and economy

- A transport required a completed owned port and rejected an inland destination.
- A California-to-Japan launch used a 30-point ocean path, deducted exactly 35% of the funded army and 25,000 gold, and took approximately **37.465 seconds**. It remained in transit after one second, then captured the landing coast and was removed from the fleet list.
- An overseas port was built and completed. With two ports, the service launched a trade ship using a 30-point route and approximately **44.958 seconds** travel time. Its arrival produced a trade-income event.
- The Weapon command launched a warship for exactly 250,000 gold. A deliberately placed hostile transport fixture within range lost health and troops when the warship fired.

### Strategic weapons

- A foreign silo source was rejected without spending gold. Omitting the source selected an owned completed silo, charged the atomic weapon's exact cost, and started its cooldown. Immediate repeat fire was rejected.
- An atomic impact removed hostile land. A completed enemy SAM fixture intercepted the next atomic missile, preserving the target territory and beginning SAM recharge.
- Hydrogen launch charged exactly 5,000,000 gold, used radius 18, and removed the targeted nation's territory in the fixture.
- MIRV launch charged its configured price. **One check failed:** targeting the Mexico capital produced only one impact event, because the other two fixed-offset warhead centres were water and the implementation skipped non-land impact centres. This was reported to the main agent for correction. A later retest must be recorded separately before this scenario can be considered fixed.

### Social rules, progression and match lifecycle

- A defeated-human fixture could take over a living AI nation once; the snapshot's player empire ID changed and further takeover was unavailable.
- Victory awarded **301 XP** in the small fixture. Cosmetic 5 then unlocked, while cosmetic 29 remained locked. Restart replaced the completed session with a fresh Spawn session.
- Two player-like tables joined one non-team multiplayer queue. Duplicate queue commands did not duplicate participants. Countdown created a shared two-human match with unique colours and automatic spawn. Public pause was rejected.
- A human alliance offer did not immediately ally the players. Reciprocal acceptance activated both sides. Allied attack was rejected without troop spending, donation transferred exactly 10% gold, expiry removed the alliance from snapshots, and the cooldown prevented an immediate new offer.
- A four-human team fixture auto-spawned with four unique colours and alternating teams. Teammate attack was rejected. Disconnecting both members of one team surrendered their land and gave both remaining teammates a win. A separate FFA survivor won after its rival disconnected.
- Full ownership snapshots used an isolated 125,000-byte buffer. Compact five-byte ownership-change records matched the authoritative buffer. A burst Sync followed immediately by StartAI was throttled and did not change modes. Leaving removed all empty test sessions.

The follow-up count includes six fixture-setup assertions. Combined with the first run, **109 assertions passed**, and the MIRV impact-area assertion failed pending correction. These are isolated server-harness checks with synthetic participants; they are not evidence of two actual network clients. No original live-game session or publisher was used.

## MIRV correction retest

The main implementation was changed to allow in-map water pixels as MIRV impact centres, while each blast still applies damage only to eligible land. A fresh clone of the **44,005-byte** installed server module repeated the Mexico-capital fixture. Both offset centres were still water, and the missile now produced **all three impact events**. The exact 25,000,000-gold cost remained correct. The temporary ModuleScript was destroyed immediately after require and the test session was left cleanly. The previously failed MIRV scenario is resolved by this targeted retest.

## Full Balanced-AI soak

A separate fresh server-module clone ran a World match with **96 AI opponents and one idle synthetic human**, Balanced difficulty and the standard 75% goal. The human was automatically assigned a safely separated capital through the same validated Spawn command; it issued no attacks or purchases. No resources or AI decisions were altered for this soak.

The simulation ran **4,800 steps of 0.25 seconds**, voluntarily yielding after each 50 steps. It reached Results at the configured **1,200-second timer**, with Greenland (empire 10) winning on 19,985 tiles, approximately 53.2% of the map's passable land. It did not reach the 75% conquest goal before the timer. Fifteen empires remained alive; the idle human had been eliminated.

Observed event counters included 83 naval launches, 82 landings, 101 strategic-weapon impacts, 197 trade arrivals, 258 completed buildings and 82 eliminations. The event stream is bounded, so these counters describe events seen after simulation steps rather than an independent complete event log. Peak active counts were 27 land attacks and nine fleets.

At the end, a full ownership-buffer scan agreed with every empire's stored land count and owned-tile set. There were no invalid owners, NaN army/gold values, negative armies or negative gold balances. No simulation exception occurred. Leaving the synthetic participant removed the empty session.

Calls to the isolated simulation step averaged **1.214 ms**, with one worst observed step of **131.54 ms**, consistent with an uncached long sea-route calculation. The average remained stable through the match; this is server-harness timing on the Studio host, not a client FPS or full multiplayer-load measurement. The configured per-match AI routing interval limits how often new naval routes are requested.

## Performance comparison, 9 November 2026

Isolated temporary modules ran in the connected Studio Server data model against the original **500 × 250** map. Each fixture used the same deterministic first-session seed, 96 Balanced AI opponents, one idle synthetic human, and 1,800 steps of 0.25 seconds (450 simulated seconds). Tests yielded every 25 steps. Temporary ModuleScript instances were destroyed immediately after require. No test publisher sent data to live players.

| Simulation step | Original | Optimized, before route scheduling | Final optimized |
| --- | ---: | ---: | ---: |
| Mean | 1.547 ms | 0.561 ms | 0.549 ms |
| 95th percentile | 2.604 ms | 0.961 ms | 0.955 ms |
| 99th percentile | 3.864 ms | 1.372 ms | 1.352 ms |
| Maximum | 130.147 ms | 2.750 ms | 3.018 ms |

The original fixture ran first and incurred cold ocean-route work. Both optimized fixtures reused the same World module's warmed route cache. **The maximum-time difference does not establish a cold-pathfinding improvement.** The enlarged-map route implementation requires its own cold-route measurements. These are Lua server-harness timings on one host; they exclude RemoteEvent serialization, network transit, and client rendering.

Before route scheduling was added, all 125,000 ownership bytes, the checked economic fields of all 97 empires, and all 169 building records exactly matched the original after 450 seconds. The final bounded scheduler still produced identical ownership bytes and 169 buildings; it had six fleets in transit instead of five because trade requests were spread across steps.

The server changes remove temporary neighbor arrays, use per-map land masks, avoid recounting unchanged structures, index defensive structures by owner, cache fleet segment lengths, and construct common snapshot arrays once per match broadcast. Economy formulas, map distances, starting territory, prices, AI decision cadence, command validation, and the network snapshot schema remain unchanged.

Bootstrap also prevents overlapping Heartbeat work and catches broadcast errors so an exceptional callback does not leave the update loop stuck. The enlarged World module prepares navigation before server startup finishes; ordinary route searches do not yield between validation and resource deduction.

### Broadcast construction

Each fixture measured 200 broadcasts with a no-op publisher. The eight-recipient case used seven additional synthetic members of the same match. Numbers below cover snapshot construction only.

| Recipients | Original mean / p95 | Optimized mean / p95 |
| --- | ---: | ---: |
| 1 | 0.131 / 0.233 ms | 0.139 / 0.296 ms |
| 8 | 0.904 / 1.305 ms | 0.138 / 0.344 ms |

Personalized outer tables, account statistics, notices, player empire IDs, and full-versus-delta choices remained independent. Shared arrays were reused only within a synchronous broadcast. Direct full snapshots still cloned the ownership buffer instead of exposing live state.

### Targeted regression checks

- Cardinal neighbor ordering and edge behavior matched the old implementation for every one of the 125,000 map cells.
- Land-mask membership matched each map's land list for 375,000 cell/map combinations across World, Europe, and Isles.
- Completed and upgraded cities affected counts and levels. Capturing a building transferred its economic benefit. Capturing a defense invalidated both owners' defense lookup correctly.
- Cached segment lengths returned the expected position on a two-segment fleet route.
- Two recipients received their own account data and private notices, with one receiving a full ownership buffer and the other receiving delta records.
- A separate isolated World wrapper counted autonomous route requests. Three private sessions with six due trade expeditions dispatched all six on successive steps, **at most one request per service step**, in rotating session/empire order. Player commands retain their existing synchronous validation and route behavior.

The larger map deliberately retains the original opening disks, distance rules, and economy formulas, providing more land rather than a full rescaling of match balance.

## Enlarged-map full Balanced-AI soak, 9 November 2026

After all updated sources were installed and Studio entered a fresh Play session, a temporary clone of the installed MatchService ran the default **96 Balanced AI opponents**, one idle synthetic human, World map, and 75% goal. The shared installed World reported **1,000 × 500**, 500,000 cells and 158,068 passable land cells. Map navigation QA had already prepared the graph and cached 64 route pairs; the soak still exercised other routes, but this is not an entirely empty-cache benchmark.

The simulation ran 4,800 steps of 0.25 seconds, split into four 1,200-step tool calls and yielding every 25 steps. It reached Results at the configured **1,200-second timer**. Colombia led with **42,939 land cells (27.2%)**; 28 empires remained alive and the idle human had been eliminated. The conquest goal was not reached before the timer.

| Simulated time | Land owned by any nation | Living empires |
| --- | ---: | ---: |
| 5 minutes | 132,553 / 158,068 (83.9%) | 70 |
| 10 minutes | 154,513 / 158,068 (97.8%) | 46 |
| 15 minutes | 155,729 / 158,068 (98.5%) | 34 |
| 20 minutes | 155,911 / 158,068 (98.6%) | 28 |

Measured service-step cost was **1.589 ms mean, 2.705 ms p95, 3.701 ms p99 and 8.143 ms maximum**. Peak active work was 33 attacks and 22 fleets. The final session contained 353 buildings. Observed events included 242 transport launches, 233 landings, 156 weapon launches, 94 explosions, 57 interceptions, 299 trade arrivals, 664 completed builds/upgrades and 69 eliminations. These counters are observations from the bounded event list after each step, not an independent lossless event log.

The final invariant scan checked all 500,000 ownership cells. Every empire's land count, owned-tile set and coordinate sums agreed with the authoritative buffer. No non-land cell had an owner; building ownership and tile indexes agreed. Army, gold, capacity, growth, income and population were finite and nonnegative for all 97 empires. Maximum observed end-state gold was approximately 292.5 million and army approximately 1.14 million. There was no simulation exception.

A full snapshot contained the required **500,000-byte isolated ownership buffer**. All 156,079 delta records accumulated during this non-broadcasting test agreed with the final buffer; this intentionally accumulated set is not representative of an ordinary 0.3-second network packet.

The isolated route-budget regression was repeated against the enlarged World: six due trade routes across three private sessions were all served in six successive steps, with at most one route search per step. A separate Bootstrap harness confirmed that a nested Heartbeat did not reenter simulation and that a caught broadcast error did not leave the guard stuck.

This single deterministic idle-human soak supports keeping the current balance for the enlarged map: neutral expansion used most of the extra room by ten minutes while faction conflict continued to the twenty-minute timer. It does not establish competitive balance, actual-client multiplayer throughput, or client FPS.
