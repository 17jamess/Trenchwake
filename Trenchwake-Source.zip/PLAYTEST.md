# Live playtesting

The reference WarFront experience was opened from its Opera page and played in Roblox. The study covered its public/private menu, map selection, difficulty and land-goal setup, capital selection, protection, troop/deployment/gold controls, contextual actions, progressive attacks, structure and weapon toolbar, and defeat flow. The recreation uses original Luau code and licensed OpenFront terrain data; it does not extract WarFront scripts or private assets.

The rebuilt game was then played in the connected Studio experience. Mesh/Image APIs were enabled by the creator after Roblox rejected the initial image-renderer attempt. A startup annotation race was corrected, the image noise reduced, and map input was aligned with the rounded image geometry. A GUI-space offset that allowed the action hint to block some map clicks was corrected.

## Two actual clients

Two independent Studio clients, Player1 and Player2, clicked World Join, appeared in the same real-player lobby, completed the countdown and automatic capital placement, and received the same session ID with different empire colours. One mouse attack captured 48 cells. Both clients reported the same 97-cell land count, 9,270 army value and captured-cell owner in the same update. No AI stood in for those participants.

Kicking the second local test client caused its land to become neutral, its empire to be eliminated, and the remaining client to receive Results with itself as winner. The phone simulator was also applied to the second client at iPhone 17 Pro settings, with a reported 750×381 viewport, and the live multiplayer HUD and map were visually inspected. Physical touchscreen gestures remain untested.

## Construction and transport interaction

A separate live Studio test temporarily used 500,000 starting gold to exercise purchases without waiting for income. The shipped configuration retains 10,000 starting gold. With ordinary UI clicks, selecting City and clicking owned land placed and completed a level-one city, increasing troop capacity to 32,000 and income. Selecting Port and clicking another owned coastal tile placed and completed a level-one port, increasing income to approximately 2,948/sec in that fixture.

Right-clicking that port opened the context menu, whose Transport action selected naval deployment. Selecting a Canadian coastline launched an actual transport carrying 7,935 troops along a six-point sea route with a 10.31-second duration. This live interaction verified launch and travel state; successful arrival and capture were verified separately in the server fixtures. At a later live observation, the destination belonged to the opponent, so the live check does not claim that the beachhead was held.

## Starting-location selector follow-up

The expanding gold selection ring was replaced with a fixed 24px precision marker. A click/tap now previews the location, and **Start Here** or Enter confirms it. Availability matches the server's land, crop, occupancy and capital-distance rules, with server validation still authoritative. The instruction card moved to the bottom so it no longer covers northern starting locations.

Live Studio mouse checks verified that ocean and occupied land disabled confirmation with specific reasons, a valid spot stayed in the selection phase with green feedback, scrolling left the marker at 24px, and clicking Start Here entered play and cleared the preview. No game errors appeared in the output log. Multiplayer players who have placed a capital see a waiting message while others choose.

The updated card was also inspected in the 750×381 iPhone 17 Pro simulator: its hint and confirmation label fit, and the Start Here button measured 108.48×36.16 pixels. Waiting-message and preview-reset presentation checks passed. Physical touchscreen input remains unverified.

## Remaining limits

The independent server checks and full 96-AI simulation are detailed in SERVER_TESTING.md; map geometry and route checks are in MAP_TESTING.md. The live two-client test does not establish 30-player performance or public cross-server operation. Studio background-client frame throttling affected a short FPS sample, so no production client-FPS claim is made. Account progress is scoped to the current server. This is a core gameplay recreation, not a verification that every WarFront shop, map, party feature or tuning value is identical.
