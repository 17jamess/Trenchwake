# Trenchwake verification — 9 November 2026

This records the initial Trenchwake larger-map, campaign-supply and field-kit UI pass. The subsequent lag/HQ revision is documented in CLIENT_LAG_TESTING.md, SERVER_LAG_TESTING.md and HEADQUARTERS_UI.md; those documents take precedence for current rendering and home-screen behavior.

## Map and embedded artwork

The World map is now **2,000 × 1,000 cells**, with **651,569 playable land cells**. Offline checks verified the exact terrain data and embedded chunks, crop bounds and **129 geographic anchors**. Europe and Isles were inspected in Studio; the Europe image seam, capital confirmation and a subsequent attack were exercised. Isles correctly clipped the second texture beyond its crop (right image X scale 1.19354844), displayed capital selection and had no Selection crosshair. The Studio console was empty at that final live check.

All **eight embedded UI assets** passed decoded-image SHA-256 verification. The existing helmet/map artwork and six construction icons are reused through cached EditableImages; no additional generation or published asset IDs were needed for this implementation.

## Isolated server simulation

`qa/GameplayChecks.luau` passed **52 checks with zero failures**. A full **1,800-second simulated match** used **168 AI empires and one synthetic human participant** and reached Results:

| Measurement | Observed value |
|---|---:|
| Initial controlled land | 2,422 cells |
| Final controlled land | 648,508 cells |
| Living empires at result | 50 |
| Peak active attacks | 152 |
| Accelerated simulation wall time | 29.4467 seconds |
| Largest measured simulation step | 36.5668 ms |

These are isolated accelerated simulation measurements on the test machine, not production frame-rate, network-load or physical-device performance claims.

`qa/CampaignChecks.luau` passed **27 checks with zero failures**. Checks covered bounded distance penalties, scale-independent supply reach, unchanged input data, identical human/AI costs, an unfinished city providing no support, a completed forward city restoring support to an existing attack, and bare-capital capture invalidating cached supply while the defeated capital's empire survives elsewhere. Both harnesses use cloned server modules, synthetic participants and no live publisher.

## UI actions and feedback

The native UI audit found feedback bindings on **60 buttons and two sliders**. A real press measured a button scale of approximately **0.96**, followed by approximately **1.025** while hovered after release. The click sounds loaded successfully, with a **0.72-second** source and **0.085** volume. Sound and reduced-motion controls were exercised; the slider track stays fixed while its knob provides feedback.

Native interaction samples exercised Solo setup, public lobby entry/leave, profile, credits/source, settings, colour selection, locked-colour explanations, map attack, pause and map-view controls. A controlled client fixture used native clicks to verify all **ten toolbar actions** route to the intended construction/weapon callbacks, plus cancellation. This fixture is callback-routing evidence; it does not claim that every weapon was purchased and fired in a live match during this UI pass.

The field-kit menu was visually inspected at the **750 × 381** iPhone simulator viewport. Desktop and compact layouts retain the existing server-owned command validation and display unavailable-tool requirements instead of silent taps.

## Remaining limits

Physical touchscreen interaction, a full 30-human-player load and production public-server operation remain unverified. The isolated 168-AI match is not a substitute for those checks. No public game release or source-hosting deployment is established by this report. Publication still requires an accessible matching source offer and the configured real source URL described in OPEN_SOURCE.md.

The final place build checks all 42 packaged sources exactly after XML round-trip. Public hosting is a separate release step; the generated source ZIP is local.
