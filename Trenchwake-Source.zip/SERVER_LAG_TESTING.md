# Server lag pass — 9 November 2026

This pass reduces repeated work in the current 2,000 × 1,000 world without reducing map size, AI population, capture budgets or gameplay features.

## Changes

- Compile eligible supply-base coordinates and squared ranges when bases change. Per-cell supply calculations now return three numbers instead of allocating input/result tables and recalculating every anchor's range. A covering base immediately establishes full support.
- Supply caches invalidate on held-capital ownership changes and completed City/Port ownership or level changes. Unrelated factories, defenses and silos no longer rebuild supply lists. An unfinished base remains ineligible until completion.
- Cache building lists by owner and kind for structure-spacing checks. Repeated AI placement attempts search the relevant structures rather than every rival's structures. Lists include unfinished construction, preserving spacing restrictions. Insertion, ownership transfer and blast deletion invalidate the cache; upgrades mutate the retained building object.
- Use direct coordinates for already validated internal tile IDs and skip defense searches for unclaimed land. External command validation remains in place.

## Controlled simulation comparison

`qa/ServerPerformance.luau` ran an isolated deterministic World scenario with **168 AI nations and one synthetic human**, **600 simulated seconds**, 2,400 steps of 0.25 seconds. It cloned server modules and attached no publisher. Navigation was prepared and a complete baseline pilot warmed the scenario's routes before either timed run. It yielded every 20 steps. The baseline was the source saved immediately before this pass in `archive/MatchService-before-lag-pass.luau`.

| Server simulation step | Before | After |
| --- | ---: | ---: |
| Mean | 3.193313 ms | 2.568945 ms |
| 95th percentile | 6.269200 ms | 5.181600 ms |
| 99th percentile | 9.717000 ms | 8.448000 ms |
| Maximum | 15.839300 ms | 16.710700 ms |

Observed mean simulation CPU time was approximately **19.6% lower**. The maximum did **not** improve. These timings cover the isolated Lua simulation on the Studio host, not client frame rate, network latency, a physical phone or production multiplayer. Other asset-preparation work was running on the host; this is one comparison, not a stable device-performance guarantee.

The timed versions produced **exactly matching ownership buffers**, checked economic fields and structure records. A further **6,804 supply evaluations** across empty, single-base, mixed/upgraded and unknown-kind anchor sets matched the detailed public supply API exactly, with zero mismatches. The public `CampaignRules.evaluate` API remains unchanged.

## Cache audit

All production structure mutations in MatchService were reviewed: creation, capture/surrender, level completion and blast deletion. Owner/kind indexes are invalidated on structural insertion, transfer and removal. They retain building references, so level completion needs no index rebuild. Completed City/Port changes and bare-capital capture invalidate compiled supply; construction completion adds a previously unfinished base. Destroying a base passes through the same ownership mutation before deletion. Restarted sessions start with empty caches, and AI takeover retains empire IDs and ownership.

The broader gameplay and campaign harnesses remain separate regression checks. This server comparison does not establish that every source of perceived gameplay lag is resolved; client map drawing and interface updates require their own measurements.
