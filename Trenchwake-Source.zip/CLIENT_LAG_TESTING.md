# Client lag pass — 9 November 2026

This records the current client changes separately from earlier, smaller-map performance reports. The raster and visible-label harnesses passed **32 checks in total with zero failures**. These measurements do not establish production frame rate or physical-device performance.

## Native client comparison

`qa/ClientPerformanceChecks.luau` ran in a Studio client against separate baseline and candidate renderer modules. Each used its own temporary parent folder and disconnected its automatic RenderStepped callback during the comparison. The fixture cleaned up its renderers and folders afterward; it did not replace the live renderer.

The raster harness passed **16 checks with zero failures**, including a final rerun after the label changes. Every ownership word and every RGBA word matched the baseline for a neutral world, a sparse full snapshot, incremental changes including a repeated tile, a palette change, and a fully occupied world. The World raster remained 2,000 × 1,000 with 651,569 land cells. The first-pass timings below are retained as originally recorded.

| Paint workload | Before CPU ms | After CPU ms | Before shaded cells | After shaded cells |
| --- | ---: | ---: | ---: | ---: |
| Neutral full paint | 208.168 | 26.355 | 651,569 | 0 |
| Sparse full snapshot | 172.621 | 16.143 | 651,569 | 5,000 |
| Incremental ownership changes | 0.246 | 0.185 | 405 | 405 |
| Sparse palette change | 164.012 | 16.408 | 651,569 | 4,949 |
| Fully occupied full snapshot | 147.015 | 144.889 | 651,569 | 651,569 |

Neutral pixels already match the cached background, so full paints now shade only owned land. Ordinary colour blending and darkening retain the same rounded bytes while avoiding three floor/clamp helper calls per painted pixel. Unchanged palette records are reused.

Paint work now uses approximately 2 ms cooperative slices instead of 4 ms. This gives other work more frequent opportunities to run; it can increase total elapsed completion time for a dense full repaint:

| Paint workload | Before elapsed ms | After elapsed ms |
| --- | ---: | ---: |
| Neutral full paint | 831.907 | 197.223 |
| Sparse full snapshot | 701.398 | 115.262 |
| Incremental ownership changes | 0.247 | 0.185 |
| Sparse palette change | 667.657 | 118.089 |
| Fully occupied full snapshot | 598.884 | 1,166.375 |

The dense case had nearly unchanged aggregate CPU cost and took longer to complete because it yielded more often. It is not evidence of faster dense full-map repaint completion. These are targeted paint measurements, excluding initial terrain-cache generation and texture upload time, from one test machine. They are not an FPS benchmark.

## Regional uploads and hidden work

Full uploads now queue only texture chunks intersecting the selected map crop. The fixture verified **182 chunks for Europe** and **30 for Isles**, compared with **2,016 for World**. With 32 × 32 RGBA chunks, the crop queues cover approximately 745 KB and 123 KB respectively, rather than uploading the entire 8 MB world image. World edge chunks can be smaller. The complete CPU raster is retained; changing maps requeues the newly exposed region.

The fixture also verified that a hidden renderer disables its ScreenGui and stops its animation work, then resumes when shown. Pending raster work is retained.

The constructor copies the neutral background directly without an initial land-shading pass. The client now waits until Spawn, Playing or Results before requiring WorldMap, generating terrain colours and allocating the gameplay images. A fresh native home-screen check verified that the menu appeared without a WarfrontAtlas instance. Returning to menu/lobby suspends an existing gameplay renderer.

## Visible-label update work

Live profiling found that only three of 169 nation labels were visible, while Update still formatted names and rewrote changed army RichText for hidden labels. The renderer now retains each empire's latest data and synchronizes text and ownership colours only when collision/camera layout shows its label. Escaped names are cached. A label is synchronized before being revealed after panning; refresh follows the existing 100 ms label-layout throttle.

`qa/LabelVisibilityChecks.luau` passed **16 checks with zero failures**. Separate baseline and candidate renderers received the same twelve packets, with all 169 army values changing in each packet and three labels visible. The measured means were:

| Native client work per packet | Before ms | After ms |
| --- | ---: | ---: |
| Update | 16.138 | 0.142 |
| Update plus label layout | 16.229 | 0.534 |

The candidate made **36 visible-label text writes across twelve packets**. Visible text matched the baseline. Hidden labels kept their latest data without changing their Text property; panning revealed the latest army and correctly escaped name. Ownership colour and dead-label hiding checks also passed. The earlier exact raster checks passed again after this change.

This fixture deliberately changes every army display value. Its timings describe that workload, not the average cost of every live packet. The same-scene CPU reduction supports the offscreen-text optimization; it does not demonstrate a production FPS increase. The pre-label-change source is retained locally in `archive/MapRenderer-before-visible-labels.luau`.

## Scope and remaining validation

StateInbox was unchanged; ownership coalescing and gameplay authority remain in their existing components. The comparison verifies rendering equivalence for the tested scenes, not every production network or device condition. Native home-to-match, capital-selection and normal gameplay checks are recorded by the main task after integrating the interface and server changes. Physical touch, full human-player load and controlled before/after production FPS remain unverified.

The baseline sources are preserved locally in `archive/MapRenderer-before-client-optimisation.luau` and `archive/Main-before-client-optimisation.luau`. Historical comparison files are separate from the current playable source package.
