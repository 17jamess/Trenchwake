# Strategy AI adaptation

`src/server/StrategyAI.luau` adapts OpenFront's trigger/reserve/expansion decisions, free-land preference, friendly-target exclusion and threat-response structure into a pure policy module for the Roblox server. Source: [OpenFrontIO commit 59742761c2b75d6f3ac583c21d6007b8e542e786](https://github.com/openfrontio/OpenFrontIO/tree/59742761c2b75d6f3ac583c21d6007b8e542e786), particularly `packages/engine/src/execution/TribeExecution.ts`, `TribeAttackBehavior.ts`, `utils/AiAttackBehavior.ts`, and `nation/NationAttackBehavior.ts`. © OpenFront and Contributors. Adaptation date: 9 November 2026. The module is AGPL-3.0-only, subject to upstream additional terms; preserve the upstream license and source offer with releases.

The module changes the upstream policy to suit the existing Roblox engine: it receives frontier candidates instead of walking OpenFront map objects, returns an intent instead of scheduling executions, uses the Roblox capacity formula, and adds deterministic tie-breaking and threat-scaled home reserves. City capacity is excluded from expansion thresholds so city completion does not abruptly halt neutral expansion. A target already being attacked is skipped, preventing a bot from filling every attack slot with duplicate pushes. Difficulty affects readiness, reserves and willingness to engage stronger opponents; the scheduler remains staggered. The policy does not grant hidden troops or bypass the normal command validation.

## Integration

Call `StrategyAI.delay(e.id, e.minor, setting.pace, s.elapsed)` for the next decision delay. Build a dictionary of frontier targets keyed by owner ID, with `tile`, `contacts`, `army`, `land`, `minor`, `alive`, `friendly`, and `protected` fields. Call `StrategyAI.choose({empire=e, elapsed=s.elapsed, difficulty=s.difficulty, commit=setting.commit, targets=targets, attacks=s.attacks})`. A result contains `tile`, `target`, `troops`, `fraction`, `reserve` and a readable `reason`. Issue it through the ordinary `startAttack` path; do not subtract troops in the policy. `StrategyAI.reserve(context, expansion)` also exposes the reserve for naval callers.

The `attacks` array must describe current attacks after troop deduction; outgoing troop stacks are not subtracted twice. `choose` itself is read-only. The caller still checks real adjacency, ownership, allies, opening protection and costs.

## Verification cases

Exercise these using isolated policy tables and then the real server match simulation:

- A ready bot with free-land contact selects expansion and retains the configured reserve.
- Insufficient troops, unspawned/dead bots, active-slot limits and duplicate target pushes produce no intent.
- Allied, protected, dead and self targets are excluded even when the caller accidentally includes them.
- An incoming stack increases home reserves; an overwhelming threat prevents unrelated neutral expansion.
- A weak neighbouring minor is preferred to a stronger major nation; viable retaliation can outrank free land.
- A city capacity increase does not change the expansion reserve basis.
- Calling the same policy with the same inputs gives the same intent and does not mutate any inputs.

Existing naval route finding, buildings, weapons and alliance validation remain the caller's responsibilities. This is a land strategy policy, not an attempt to reproduce every upstream nation subsystem.
