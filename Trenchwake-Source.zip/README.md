# Trenchwake

**HOLD THE FRONT. KEEP IT SUPPLIED.** A Roblox territory strategy game with a field-kit interface, a larger world and forward bases that support distant advances. Trenchwake is the working game name; its availability has not been established as trademark clearance.

Gameplay includes Luau adaptations of OpenFront's public source. **© OpenFront and Contributors.** This is an unofficial adaptation with no OpenFront endorsement. Combined code: GNU AGPL v3 with the upstream attribution/origin terms. OpenFront map data and adapted geography: CC BY-SA 4.0. See LICENSE, LICENSE-ASSETS, ATTRIBUTION.md and OPEN_SOURCE.md.

## Open and play

1. Open **Trenchwake.rbxlx** in Roblox Studio.
2. In **Experience Settings → Security**, enable **Allow Mesh / Image APIs** (`AllowMeshImageAPIs`). The terrain and embedded interface artwork use EditableImage. This setting must be enabled for the experience; the place builder does not bypass it.
3. Press **Play**, select **Solo** on the home screen and choose **Play**. Select World, Europe or Isles in setup, then start. The World and Teams tabs instead join the corresponding public queue.
4. Hover over land to preview your starting territory; click or tap to choose it. The confirmation panel explains availability; choose **Start Here** or press **Enter**. Expand into neighbouring territory and reach the selected control goal, or lead when the campaign timer expires.

World and Team Battle public queues need at least two real players in the same server. They do not provide cross-server ranked matchmaking. The configured Roblox page is https://www.roblox.com/games/123209925514168; public access and account eligibility still require publishing verification. Set the experience capacity to match `Config.MaxPlayers` when preparing multiplayer.

## What defines this version

- The World raster is **2,000 × 1,000**, with **651,569 playable land cells**, 4.12 times the preceding world's land area. Europe and Isles use detailed crops of the same data. Two terrain textures support the full map without exceeding the per-image size limit.
- Held capitals and completed cities/ports support nearby advances. Overextended attacks take longer and lose more attacking troops. Forward bases and city/port upgrades improve reach; human and AI attackers use the same rules. Supply is geographic reach, not a simulation of connected or cuttable logistics routes.
- Campaigns can last **30 minutes**, with **24 major and 144 minor AI opponents** in solo play. Starting territory remains small. AI considers frontier sites for supply bases, keeps reserves and makes staggered attack decisions.
- The home screen now uses a custom graphic wordmark, punchier arcade colours, three original illustrated navigation buttons and one mode-aware Play action. The battle HUD uses a small floating dock with tools and details opening on demand. Buttons have press/release bounce and a quiet click; sliders pulse once per gesture. Settings can mute sound or reduce motion. Unavailable actions explain their requirements.
- The map-selection crosshair has been removed. Capital selection still uses the confirmation panel; attack and building markers retain their gameplay functions.
- Capital placement has a bright translucent territory preview, clicks leave a brief diamond marker, and buildings use illustrated logos. Completed factories lay persistent land-only railways to nearby cities/ports, including foreign facilities. Tracks survive conquest. Rail geometry is cached and sent only when it changes.
- Smaller capture batches slow expansion; the opening camera shows smaller land cells without increasing the terrain raster. AI rotates its frontier checks and active-front processing to prevent idle or starved attacks.

## Controls and systems

- Click neighbouring land to attack. Open **Send %** for the continuous **1–100%** army slider or percentage presets.
- Drag to pan, scroll or pinch to zoom; WASD/arrow keys also pan and **H** recentres.
- **Tab / Hide** clears the floating controls; **Show** restores them. **Build** opens the complete construction/weapon palette, and **More** opens utilities, rankings and active fronts.
- **1–0** select City, Port, Factory, Defense, Silo, SAM, Warship, Atom, Hydrogen and MIRV. Then choose a valid map location.
- Right-click a region for available attack, construction, alliance, donation or transport actions. Use an owned coastal port to launch transport.
- Recall attacks with their retreat buttons. **Space** pauses a solo match; **Escape** cancels the selected action.

The server validates ownership, terrain, costs, cooldowns and requirements. Systems include construction/upgrades, economy, opening protection, naval transport, warships, missiles/interception, alliances, donations, elimination, spectating, results and a free solo AI takeover. Factories and territory earn gold; cities increase capacity and income as well as supply reach. There is no idle supply attrition or permanent inability to expand after losing a base.

Profile statistics, challenges, XP and colour unlocks last for the current server session. Account persistence and paid products are not implemented.

## Validation and limits

The gameplay and campaign harnesses passed **52 and 27 checks** again after the lag pass, using a 300-second, 168-AI regression scenario. The preceding campaign version also completed a 1,800-second simulated match with 168 AI opponents. Native Studio interaction verified the main menu, settings, queues, capital confirmation, an attack and sampled controls; a funded UI fixture checked all ten toolbar action mappings. World data and all seventeen embedded artwork decodes passed exact offline verification. Europe and Isles were inspected in Studio, including the two-texture crop seam and absence of the selection crosshair.

The current map/rail/AI revision passed **149 checks**, including all 168 AI nations making territorial progress in a two-minute activity scenario. See **MAP_AND_RAIL_TESTING_2026-11-11.md** for current behaviour, timing evidence and balance limits. Earlier lag work is recorded in **TRENCHWAKE_TESTING.md**, **CLIENT_LAG_TESTING.md** and **SERVER_LAG_TESTING.md**. The compact layout checks are documented in MINIMAL_UI_2026-11-11.md; the graphic treatment and menu checks are in GAME_CHROME_2026-11-11.md. HEADQUARTERS_UI.md records the superseded design. Phone landscape layout was inspected in the Studio device simulator. Physical touch, a full 30-human load and published production joining remain unverified. Simulation timing does not establish production frame rate or final balance. Earlier testing documents describe earlier revisions.

## Editable source and rebuild

Run `./rebuild-place.ps1` to generate **Trenchwake.rbxlx**. It first packages the complete local source, then embeds that exact ZIP in **ServerStorage.SourceDistribution** with its hash and extraction instructions. It packages **56 scripts/modules** and checks every source exactly after an XML round trip; source-distribution StringValues add no executable scripts or client replication. Windows PowerShell/.NET is sufficient; no downloads are needed for the ordinary rebuild. **dist/Trenchwake-Source.zip** includes source, licensed art, QA, notices and build materials with a SHA-256 manifest. See SOURCE_DISTRIBUTION.md for extraction from a downloaded XML place.

| Source | Purpose |
| --- | --- |
| `src/shared/Config.luau` | Title, pacing, counts and balancing |
| `src/shared/CombatRules.luau`, `CampaignRules.luau` | Combat costs and forward supply |
| `src/shared/RailNetwork.luau` | Incremental, persistent land-only railway graph |
| `src/shared/WorldMap.luau`, `TerrainData*.luau` | Geography, crops, navigation and embedded terrain |
| `src/server/MatchService.luau`, `AttackFrontier.luau`, `StrategyAI.luau` | Authoritative match simulation and AI |
| `src/client/Interface.luau`, `FieldSkin.luau`, `BattleHUD.luau`, `GameTheme.luau`, `ButtonFeedback.luau` | Interface, layout and interaction feedback |
| `src/client/MapRenderer.luau`, `StateInbox.luau` | Tiled terrain rendering and incoming state |
| `src/client/FieldArt.luau`, `src/shared/FieldArtData*.luau` | Portable artwork decoder and data |
| `src/client/Main.client.luau`, `src/server/Bootstrap.server.luau` | Client/server entry points |

The internal `Warfront` folder and instance names remain for compatibility; the displayed game title is Trenchwake. The workspace's original Crownfall project and historical builds are preserved separately.

## Credits and public release

Upstream research and port details are recorded in COMBAT_PORT.md, AI_PORT.md and CAMPAIGN_PORT.md. Full World source provenance is in assets/WORLD_FULL_SOURCE.md; editable UI artwork is in assets/field-kit/.

The free source offer uses Roblox's supported copying route: on the game's Roblox page, choose **⋯ → Edit in Studio**, then save a copy. All running Luau is editable; the complete source ZIP, build files, assets and licences are in **ServerStorage.SourceDistribution**. `Config.SourceURL` points to the game's Roblox page. Before public access, enable **Allow users to download a copy of this Place**, verify non-owner copying and archive extraction, and keep the offer matched to every deployed version. See OPEN_SOURCE.md and SOURCE_DISTRIBUTION.md. An additional public repository has been created at **https://github.com/17jamess/Trenchwake**; its release upload and public download still require verification. These prepared files do not confirm that Roblox public access is live. Proprietary OpenFront assets and third-party game assets are excluded.
