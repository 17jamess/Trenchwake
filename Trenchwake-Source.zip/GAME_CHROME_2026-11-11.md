# Roblox game chrome revision — 11 November 2026

The current revision uses `GameTheme.luau` for shared navy panels, dark outlines, raised button faces and bold live captions. The home menu, compact battle controls, setup, settings, profile, results and context actions now share the same graphic treatment. Build, Send and More retain distinct gold, teal and blue faces. Four original HUD graphics—helmet, coin, hammer and flag—are included as editable SVGs and 96 × 96 PNGs. This pass used no image-generation call.

The home profile uses a Roblox player thumbnail when available, with the helmet graphic as its fallback. Button decoration does not own callbacks or create additional hit areas; native button text and the visible `GameCaption` stay synchronized.

## Verified in Studio

- The battle dock retains its **440 × 48 pixel** bounds. At a 1043.2 × 536 viewport, persistent HUD coverage remained **6.21795%**.
- Native desktop clicks in a funded callback fixture routed all six build actions and all four weapon actions correctly, plus Cancel once. Zoom In and Zoom Out retained their expected −1 and +1 callback arguments.
- More → Settings toggled sound Off and reduced motion On. Native button text and the corresponding `GameCaption` matched the updated state exactly. Sound was restored On and motion restored Full afterward.
- Pause and Recall All each produced exactly one intended callback in their fixture.
- The Rankings dialog displayed two fixture nations in the correct order, with **0.6%** and **0.3%** land shares.
- Initial selected-face states are retained for setup map/goal choices and the default **25%** deployment preset after applying the theme.
- All **17 embedded artwork decode checks** passed.
- The gold ring around the player's active attacks is disabled. A focused client fixture verified that troop labels remain visible, incoming warnings retain their red rings, reused markers update correctly when the viewing nation changes, unrelated attacks stay hidden and completed markers are removed.

The native Roblox toolbar remained visible during testing. Zoom controls were moved below the inset reported by `GuiService:GetGuiInset()` so that the toolbar does not cover their input area.

These funded fixtures verify native interface routing and state presentation. They do not establish that every weapon was purchased or fired in a live match, and they are not production-performance measurements. At a 750 × 381 phone simulator viewport, the styled dock and toolbar clearance were visually checked and persistent coverage remained 12.1673%. After its initial property signals settled, the 25% preset retained its gold face and dark caption. Physical touchscreen behavior is unverified.
