# OpenFront gameplay adaptation — verified 9 November 2026

## Implemented

- Persistent priority-queued attack frontiers replace repeated scans of all borders. Capture still requires live cardinal adjacency, eligible land and current target ownership.
- OpenFront-derived combat separates neutral expansion from defended land and applies terrain, army strength, defending density, territory-size and defense-post effects. Work remains bounded per attack and per match.
- Repeated land deployments reinforce an existing push. Opposing committed stacks cancel before reaching land. Naval landings use the same casualty rules and continue from their beachhead.
- AI uses staggered decisions, readiness thresholds, defensive reserves, incoming-threat response, weak-target scoring, and duplicate-target prevention.
- Map markers display our active pushes and incoming threats with live troop counts. Pulsing respects reduced-motion settings.
- Visible copyright and a Credits / Source panel accompany license files, provenance and a complete editable-source packaging script. The public source address is deliberately unset; hosting it is a release step.

## Isolated Studio server checks

`qa/GameplayChecks.luau` clones MatchService and its server helper modules into a private ServerStorage folder, binds no live publisher, and uses synthetic participants. It runs actual command/step logic with controlled fixture maps, and then cleans up. It does not modify a player's live match.

The initial suite passed **41 checks, zero failures**, including:

- Stronger attacks improve casualty/speed behavior; difficult terrain and completed defenses cost more.
- Ordinary and reinforced troop commitments spend the exact available amount, and retreat cannot invent troops.
- Opposing attacks cancel with only the uncancelled remainder surviving.
- Conquest stays contiguous and cannot jump remote gaps.
- A narrow, one-cell frontier eventually advances. Review found and fixed an initial time-budget ceiling that could otherwise stall expensive cells indefinitely.
- AI keeps reserves, avoids active duplicate targets, respects friendly/protected targets, responds to overwhelming incoming attacks, and continues neutral expansion after new city capacity is added.

Two independent 96-bot World simulations used the normal economy and AI:

| Run | Simulated time | Starting controlled cells | Final controlled cells | Living empires | Peak active attacks | Largest measured step | Simulation wall time | Final phase |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| Opening soak | 300 s | 1,554 | 78,485 | 75 | 87 | 4.44 ms | 1.15 s | Playing |
| Full match | 1,200 s | 1,554 | 156,230 | 32 | 87 | 8.74 ms | 5.30 s | Results |

Both runs passed all 41 checks, including finite/bounded armies, ownership counts and territorial progress. These are accelerated isolated server measurements on this machine, with cooperative yields; they are not frame-rate, network-load or production-performance benchmarks.

After expanding naval coverage, the final targeted suite passed **52 checks, zero failures** with the soak disabled. The 11 added checks covered successful beachheads, exact defending density losses, fleet-to-attack troop conservation, continuing conquest, repelled weak invasions, and one-time allied refunds. Only the QA harness changed between the full-match run and these additional assertions.

## Live Studio interaction and visuals

- The new modules loaded successfully, and the ordinary game booted with the map and menus.
- Ordinary mouse clicks opened Credits / Source, configured a private match, previewed a valid capital and confirmed it.
- An ordinary map attack deducted a deployment, progressively enlarged the territory and displayed a live gold front marker and troop count. The HUD and active-attack list updated.
- Desktop Credits / Source text and the five menu entries were visually inspected.
- iPhone 17 Pro simulator used a **750 × 381** viewport with **LandscapeSensor**, DeviceSafeInsets and safe-area clipping. The menu was inspected and its tab tap areas increased to approximately **107 × 43.5 px**. A separate Interface layout fixture verified the Credits / Source panel's wrapping and bounds in that viewport.
- The simulator's mouse automation did not reliably select the intended menu item. The phone panel check is a visual layout check, not verified physical touch interaction. Physical phone controls remain unverified.
- The final fresh playtest console was empty. Earlier console entries from mistaken inspection paths were tooling errors, not game simulation failures.
- Play mode was stopped and Studio reset to the default viewport after verification.

## Packaging and remaining limits

`rebuild-place.ps1` packages **15** scripts/modules and checks exact source round trips through the generated XML. `package-source.ps1` packages preferred sources, map assets, tests, license files and build instructions with a SHA-256 manifest. Archived places and the upstream reference checkout are excluded.

The previous place is retained at `archive/Warfront-before-openfront-gameplay.rbxlx`. The separate Crownfall project was not edited.

The prior two-client multiplayer evidence in PLAYTEST.md predates this combat/AI pass. No new two-client or 30-player test was performed in this pass. Public matchmaking, persistence, production load, physical touch controls and legal/platform compatibility of a future release are not established by these checks. Before publication, host the matching source and set Config.SourceURL; no game or source has been publicly published by this work.
