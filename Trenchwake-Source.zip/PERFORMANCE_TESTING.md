# Larger map and performance pass — 9 November 2026

All changes were installed into the connected Studio experience and tested in a fresh Play session. The local place includes the same sources. Publishing and production load testing were not performed.

## Map and simulation

The raster increased from 500×250 to 1000×500. Playable land increased from 37,575 to 158,068 cells. Opening empire size, costs and gameplay radii remain unchanged, providing more room between empires. Maximum zoom and initial camera focus account for the new resolution.

On an identical old-map 96-AI fixture, simulation step time fell from 1.55 ms mean to 0.55 ms mean. Snapshot construction for eight synthetic recipients fell from 0.90 ms to 0.14 ms mean. These are measured Lua processing times, not client FPS or network latency. Exact-state comparisons and cache caveats are in SERVER_TESTING.md.

The larger map passed 4,800 steps covering 20 simulated minutes with 96 Balanced AI opponents. Mean step time was 1.59 ms, p95 2.71 ms, worst 8.14 ms. The final full ownership and economic invariant scan passed. Map occupancy reached 83.9% at five minutes and 97.8% at ten minutes, so no broad balance scaling was applied.

Sixty-four cold sea routes took 1.29 ms median, 3.90 ms p95 and 6.24 ms worst. Returned segments and graph edges did not cross land. The server prepares navigation during startup with bounded yielding; ordinary match routes do not yield inside validated commands. Autonomous routes are scheduled fairly, one request per simulation step. See MAP_TESTING.md for route samples and limitations.

## Client drawing and ownership updates

The renderer keeps terrain colours in memory, queues changed 32×32 regions, coalesces adjacent regions, and limits uploads to 96 KiB and approximately 1.5 ms of upload work per frame. Individual API calls cannot be preempted. Full paints are processed in approximately 4 ms CPU slices and their uploads spread across frames. These are work budgets, not a guaranteed frame rate.

An isolated renderer fixture ran in the actual Studio Client using an ordinary temporary LocalScript:

- A sparse one-cell ownership change uploaded **4,096 bytes in one call**, instead of a complete **2,000,000-byte** image.
- A packet containing a full ownership buffer and a newer delta retained the newer owner.
- Across 31 settled frames, unchanged camera and route layout counts remained unchanged. No unnecessary label collision layout was performed without new data.
- Screen coordinates converted back to the original cell ID through the picking function.
- The temporary renderer, scripts and test folder were removed.

A live larger-map sample covering 7,485 frames and 419 updates measured 0.018 ms average animation work and 0.351 ms maximum. Update processing averaged 2.64 ms. Its maximum aggregate CPU time was 42.19 ms for an update including a full paint; that paint was divided into yielding slices. This was one zoomed view with few visible annotations, not a busy late-game or production-FPS benchmark. The earlier renderer sample used a different scene, so no controlled before/after client-FPS claim is made.

StateInbox passed nine regression checks and 100 deterministic randomized ownership replay batches. Tests covered packed/table changes, conflicting changes, latest-full resets, tile 500,000, owner zero, session/phase/player/map boundaries, ordered/deduplicated events and queue reuse. Coalescing preserves ownership changes while dropping obsolete presentation snapshots.

## Screen space and direct interaction

The command bar is 98 logical pixels high on sufficiently wide desktops and 142 on smaller views, previously 160/170. Wide layouts require at least a 1280×600 viewport so tool prices have room. Rankings and the top control strip are shorter.

The iPhone 17 Pro simulator reported a 750×381 viewport. The command bar measured 95.09 physical pixels high, all ten prices fit their labels, and the Map View button was clicked through the native Studio preview. The bar, ranking and control panel disappeared; the full-width header background also cleared. Commands restores them, and a new match restores controls automatically. Map View retains an active placement action so the player can place it on the cleared map.

A real map click in that phone preview started an attack: the selected neutral tile changed from owner 0 to the human's owner 1. Existing desktop Tab/button input and screen-to-cell conversion were also exercised. Physical touchscreen gestures and production device performance remain unverified.

At the HD 1080 desktop setting, the viewport reported 1919×1079 and the single-row bar measured 117.49 physical pixels high. All ten action names and prices fit their labels. Starting a new Europe match after collapsing the HUD restored its controls and rendered the 212×198 crop.

Temporary profiling scripts and source wrappers were removed by ending their Play sessions. No test resources or altered starting funds are included. Config.StartingGold remains 10,000. The prior local place is preserved in archive/Warfront-before-performance.rbxlx.

The rebuilt place contains twelve scripts/modules. XML source round-trip checks passed, and installed source byte lengths and rolling checksums matched the local source files. All source modules are below Studio's 200 KB limit.
